package service;

import models.*;
import models.enums.ToolType;
import models.enums.ToolMaterial;

/**
 * سرویس مدیریت ابزارهای بازیکن
 */
public class ToolService {
    private final Player player;
    private boolean isInBlacksmith = false;

    public ToolService(Player player) {
        this.player = player;
    }

    // ========== تجهیز ابزار ==========
    /**
     * تجهیز ابزار از کوله پشتی
     * @param toolName نام ابزار
     * @return پیام نتیجه عملیات
     */
    public String equipTool(String toolName) {
        try {
            ToolType type = ToolType.valueOf(toolName.toUpperCase());
            Tool tool = player.getTool(type);
            
            if (tool != null) {
                player.setEquippedTool(tool);
                return tool.getDisplayName() + " تجهیز شد";
            } else {
                return "این ابزار در کوله پشتی شما وجود ندارد";
            }
        } catch (IllegalArgumentException e) {
            return "ابزار نامعتبر";
        }
    }

    // ========== نمایش ابزارها ==========
    /**
     * نمایش ابزار فعلی
     */
    public String showCurrentTool() {
        Tool tool = player.getEquippedTool();
        return tool != null ? 
            "ابزار فعلی: " + tool.getDisplayName() : 
            "هیچ ابزاری تجهیز نشده است";
    }

    /**
     * نمایش ابزارهای موجود
     */
    public String showAvailableTools() {
        StringBuilder sb = new StringBuilder("ابزارهای موجود:\n");
        player.getTools().forEach((type, tool) -> {
            sb.append("- ").append(tool.getDisplayName()).append("\n");
        });
        return sb.toString();
    }

    // ========== ارتقای ابزار ==========
    /**
     * ارتقای ابزار
     * @param toolName نام ابزار
     * @param material جنس جدید
     * @return پیام نتیجه عملیات
     */
    public String upgradeTool(String toolName, ToolMaterial material) {
        if (!isInBlacksmith) {
            return "برای ارتقای ابزار باید در آهنگری باشید";
        }
        
        try {
            ToolType type = ToolType.valueOf(toolName.toUpperCase());
            Tool tool = player.getTool(type);
            
            if (tool == null) {
                return "این ابزار را ندارید";
            }
            
            if (tool.upgrade(material)) {
                return tool.getDisplayName() + " با موفقیت ارتقا یافت";
            } else {
                return "ارتقا ناموفق. جنس جدید باید بهتر از جنس فعلی باشد";
            }
        } catch (IllegalArgumentException e) {
            return "ابزار نامعتبر";
        }
    }

    // ========== استفاده از ابزار ==========
    /**
     * استفاده از ابزار فعلی
     * @param direction جهت استفاده
     * @return نتیجه استفاده از ابزار
     */
    public String useTool(String direction) {
        Tool tool = player.getEquippedTool();
        if (tool == null) {
            return "هیچ ابزاری تجهیز نشده است";
        }

        // مصرف انرژی
        int energyCost = tool.getEnergyCost();
        // اینجا باید انرژی بازیکن کاهش یابد (وابسته به سیستم انرژی)
        
        switch (tool.getType()) {
            case HOE:
                return useHoe(direction);
            case PICKAXE:
                return usePickaxe(direction);
            case AXE:
                return useAxe(direction);
            case WATERING_CAN:
                return useWateringCan(direction);
            case FISHING_ROD:
                return useFishingRod();
            case SCYTHE:
                return useScythe(direction);
            case MILK_PAIL:
                return useMilkPail();
            case SHEARS:
                return useShears();
            default:
                return "این ابزار قابل استفاده نیست";
        }
    }

    // ========== متدهای استفاده از ابزارهای خاص ==========
    private String useHoe(String direction) {
        return "خاک با بیل شخم زده شد (" + direction + ")";
    }

    private String usePickaxe(String direction) {
        return "با کلنگ به سنگ ضربه زده شد (" + direction + ")";
    }

    private String useAxe(String direction) {
        return "با تبر به درخت ضربه زده شد (" + direction + ")";
    }

    private String useWateringCan(String direction) {
        return "گیاهان آبیاری شدند (" + direction + ")";
    }

    private String useFishingRod() {
        return "چوب ماهیگیری پرتاب شد";
    }

    private String useScythe(String direction) {
        return "با داس گیاهان بریده شدند (" + direction + ")";
    }

    private String useMilkPail() {
        return "شیر دوشیده شد";
    }

    private String useShears() {
        return "پشم چیده شد";
    }

    // سایر متدهای کمکی...
}