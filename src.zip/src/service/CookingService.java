package service;

import models.*;
import models.enums.FoodType;
import models.enums.ItemType;

/**
 * سرویس مدیریت آشپزی
 */
public class CookingService {
    private final Player player;
    private final EnergyService energyService;
    private final InventoryService inventoryService;

    public CookingService(Player player, EnergyService energyService, 
                        InventoryService inventoryService) {
        this.player = player;
        this.energyService = energyService;
        this.inventoryService = inventoryService;
    }

    // ========== مدیریت یخچال ==========
    /**
     * قرار دادن آیتم در یخچال
     */
    public String putInRefrigerator(ItemType item, int count) {
        if (!player.isInHome()) {
            return "برای استفاده از یخچال باید در خانه باشید";
        }

        if (!inventoryService.hasItem(item, count)) {
            return "موارد مورد نظر را در کوله پشتی ندارید";
        }

        if (!isFoodItem(item)) {
            return "این آیتم قابل قرار دادن در یخچال نیست";
        }

        if (player.getRefrigerator().isFull()) {
            return "یخچال پر است";
        }

        inventoryService.removeItem(item, count);
        player.getRefrigerator().addItem(item, count);
        return String.format("%d عدد %s در یخچال قرار داده شد", count, item.name());
    }

    /**
     * برداشتن آیتم از یخچال
     */
    public String pickFromRefrigerator(ItemType item, int count) {
        if (!player.isInHome()) {
            return "برای استفاده از یخچال باید در خانه باشید";
        }

        if (!player.getRefrigerator().hasItem(item)) {
            return "این آیتم در یخچال وجود ندارد";
        }

        if (inventoryService.isFull()) {
            return "کوله پشتی پر است";
        }

        player.getRefrigerator().removeItem(item, count);
        inventoryService.addItem(item, count);
        return String.format("%d عدد %s از یخچال برداشته شد", count, item.name());
    }

    // ========== نمایش دستورالعمل‌ها ==========
    /**
     * نمایش دستورالعمل‌های یاد گرفته شده
     */
    public String showRecipes() {
        StringBuilder sb = new StringBuilder("دستورالعمل‌های آشپزی:\n");
        
        player.getRecipes().values().stream()
            .filter(Recipe::isLearned)
            .forEach(recipe -> {
                sb.append("- ").append(recipe.getResult().getPersianName()).append(": ");
                recipe.getIngredients().forEach((item, count) -> {
                    sb.append(item.name()).append(" (").append(count).append(") ");
                });
                sb.append("\n");
            });
        
        return sb.toString().trim();
    }

    // ========== پخت غذا ==========
    /**
     * پخت یک غذا
     */
    public String prepareFood(FoodType foodType) {
        if (!player.isInHome()) {
            return "برای پخت غذا باید در خانه باشید";
        }

        Recipe recipe = player.getRecipes().get(foodType);
        if (recipe == null) {
            return "دستورالعمل این غذا وجود ندارد";
        }

        if (!recipe.isLearned()) {
            return "شما این دستور آشپزی را یاد نگرفته‌اید";
        }

        if (!recipe.canCook(player)) {
            return "مواد اولیه کافی ندارید";
        }

        if (inventoryService.isFull()) {
            return "فضای کافی در کوله پشتی ندارید";
        }

        // مصرف انرژی
        if (!energyService.hasEnoughEnergy(3)) {
            return "انرژی کافی برای پخت غذا ندارید";
        }
        energyService.decreaseEnergy(3);

        // مصرف مواد اولیه
        recipe.getIngredients().forEach((item, count) -> {
            // اول از یخچال بردارد، اگر نبود از اینونتوری
            int fromFridge = Math.min(count, player.getRefrigerator().getItemCount(item));
            if (fromFridge > 0) {
                player.getRefrigerator().removeItem(item, fromFridge);
                count -= fromFridge;
            }
            if (count > 0) {
                inventoryService.removeItem(item, count);
            }
        });

        // اضافه کردن غذا به اینونتوری
        Food cookedFood = new Food(foodType);
        inventoryService.addFood(cookedFood);
        
        return String.format("%s با موفقیت پخته شد!", foodType.getPersianName());
    }

    // ========== خوردن غذا ==========
    /**
     * خوردن یک غذا
     */
    public String eatFood(FoodType foodType) {
        if (!inventoryService.hasFood(foodType)) {
            return "این غذا را در کوله پشتی ندارید";
        }

        Food food = inventoryService.getFood(foodType);
        
        // اعمال اثر غذا
        energyService.increaseEnergy(food.getType().getEnergyRestore());
        
        // اعمال باف
        if (food.getBuffType() != null) {
            player.setActiveBuff(food);
        }
        
        // حذف غذا از اینونتوری
        inventoryService.removeFood(foodType);
        
        return String.format("%s خورده شد! +%d انرژی", 
            foodType.getPersianName(), food.getType().getEnergyRestore());
    }

    // ========== یادگیری دستورالعمل ==========
    /**
     * یادگیری یک دستورالعمل جدید
     */
    public String learnRecipe(FoodType foodType) {
        if (player.getRecipes().containsKey(foodType)) {
            Recipe existing = player.getRecipes().get(foodType);
            if (existing.isLearned()) {
                return "شما قبلاً این دستور را یاد گرفته‌اید";
            }
            
            // آپدیت دستور به یاد گرفته شده
            player.getRecipes().put(foodType, new Recipe(
                existing.getResult(),
                existing.getIngredients(),
                true,
                existing.getRequiredSkillLevel()
            ));
            
            return String.format("دستور پخت %s یاد گرفته شد!", foodType.getPersianName());
        }
        return "این دستور آشپزی وجود ندارد";
    }

    // ========== متدهای کمکی ==========
    private boolean isFoodItem(ItemType item) {
        // لیست آیتم‌های غذایی
        return item == ItemType.WHEAT || item == ItemType.EGG || 
               item == ItemType.MILK || item == ItemType.VEGETABLE;
    }
}