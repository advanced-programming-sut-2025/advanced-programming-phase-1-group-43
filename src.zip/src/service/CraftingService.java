package service;

import models.*;
import models.enums.ItemType;

/**
 * سرویس مدیریت ساخت و ساز
 */
public class CraftingService {
    private final Player player;
    private final EnergyService energyService;

    public CraftingService(Player player, EnergyService energyService) {
        this.player = player;
        this.energyService = energyService;
    }

    // ========== نمایش دستورالعمل‌ها ==========
    /**
     * نمایش تمام دستورالعمل‌های یاد گرفته شده
     */
    public String showRecipes() {
        StringBuilder sb = new StringBuilder("دستورالعمل‌های ساخت:\n");
        
        player.getCraftingStation().getRecipes().values().stream()
            .filter(Recipe::isLearned)
            .forEach(recipe -> {
                sb.append("- ").append(recipe.getResult().getPersianName()).append(": ");
                recipe.getIngredients().forEach((item, count) -> {
                    sb.append(item.getPersianName()).append(" (").append(count).append(") ");
                });
                sb.append("\n");
            });
        
        return sb.toString().trim();
    }

    // ========== ساخت آیتم ==========
    /**
     * ساخت یک آیتم
     * @param itemName نام آیتم
     * @return پیام نتیجه عملیات
     */
    public String craftItem(String itemName) {
        if (!player.getCraftingStation().isInHome()) {
            return "برای ساخت آیتم باید در خانه باشید";
        }

        try {
            ItemType itemType = ItemType.valueOf(itemName.toUpperCase());
            Recipe recipe = player.getCraftingStation().getRecipes().get(itemType);
            
            if (recipe == null) {
                return "دستورالعمل ساخت این آیتم وجود ندارد";
            }
            
            if (!recipe.isLearned()) {
                return "شما این دستورالعمل را یاد نگرفته‌اید";
            }
            
            if (!recipe.canCraft(player)) {
                return "مواد اولیه کافی ندارید";
            }
            
            if (player.getInventory().isFull()) {
                return "فضای کافی در کوله پشتی ندارید";
            }
            
            // مصرف انرژی
            if (!energyService.hasEnoughEnergy(2)) {
                return "انرژی کافی برای ساخت آیتم ندارید";
            }
            energyService.decreaseEnergy(2);
            
            // مصرف مواد اولیه
            recipe.getIngredients().forEach((item, count) -> {
                player.getInventory().removeItem(item, count);
            });
            
            // اضافه کردن آیتم ساخته شده
            player.getInventory().addItem(itemType, recipe.getResultCount());
            
            return String.format("%s با موفقیت ساخته شد!", itemType.getPersianName());
            
        } catch (IllegalArgumentException e) {
            return "آیتم نامعتبر";
        }
    }

    // ========== یادگیری دستورالعمل ==========
    /**
     * یادگیری یک دستورالعمل جدید
     * @param itemName نام آیتم
     */
    public String learnRecipe(String itemName) {
        try {
            ItemType itemType = ItemType.valueOf(itemName.toUpperCase());
            player.getCraftingStation().learnRecipe(itemType);
            return String.format("دستورالعمل ساخت %s یاد گرفته شد!", itemType.getPersianName());
        } catch (IllegalArgumentException e) {
            return "آیتم نامعتبر";
        }
    }

    // ========== قرار دادن آیتم در جهان ==========
    /**
     * قرار دادن آیتم در جهان بازی
     * @param itemName نام آیتم
     * @param direction جهت قرار دادن
     */
    public String placeItem(String itemName, String direction) {
        try {
            ItemType itemType = ItemType.valueOf(itemName.toUpperCase());
            
            if (!player.getInventory().hasItem(itemType)) {
                return "این آیتم را در کوله پشتی ندارید";
            }
            
            // اینجا باید منطق قرار دادن آیتم در جهان بازی پیاده‌سازی شود
            // فعلاً فقط یک پیام نمایش می‌دهیم
            player.getInventory().removeItem(itemType, 1);
            return String.format("%s در جهت %s قرار داده شد", 
                itemType.getPersianName(), direction);
            
        } catch (IllegalArgumentException e) {
            return "آیتم نامعتبر";
        }
    }

    // ========== چیت کد ==========
    /**
     * اضافه کردن آیتم با چیت کد
     * @param itemName نام آیتم
     * @param count تعداد
     */
    public String cheatAddItem(String itemName, int count) {
        if (count <= 0) {
            return "تعداد باید بیشتر از صفر باشد";
        }

        try {
            ItemType itemType = ItemType.valueOf(itemName.toUpperCase());
            
            if (player.getInventory().getFreeSlots() < 1) {
                return "فضای کافی در کوله پشتی ندارید";
            }
            
            player.getInventory().addItem(itemType, count);
            return String.format("%d عدد %s به کوله پشتی اضافه شد", 
                count, itemType.getPersianName());
            
        } catch (IllegalArgumentException e) {
            return "آیتم نامعتبر";
        }
    }
}