package util;

import models.Tool;
import models.enums.ToolType;

/**
 * کلاس کمکی برای محاسبات مربوط به ابزارها
 */
public class ToolUtils {
    /**
     * بررسی آیا ابزار می‌تواند روی یک تایل خاص استفاده شود
     */
    public static boolean canUseToolOnTile(Tool tool, String tileType) {
        switch (tool.getType()) {
            case HOE:
                return tileType.equals("soil") || tileType.equals("grass");
            case PICKAXE:
                return tileType.equals("stone") || tileType.equals("ore");
            case AXE:
                return tileType.equals("tree") || tileType.equals("log");
            case WATERING_CAN:
                return tileType.equals("water") || tileType.equals("crop");
            case SCYTHE:
                return tileType.equals("grass") || tileType.equals("crop");
            default:
                return false;
        }
    }

    /**
     * محاسبه کیفیت کار ابزار بر اساس جنس آن
     */
    public static int calculateToolEfficiency(Tool tool) {
        switch (tool.getMaterial()) {
            case BASIC: return 1;
            case COPPER: return 2;
            case IRON: return 3;
            case GOLD: return 4;
            case IRIDIUM: return 5;
            default: return 1;
        }
    }
}