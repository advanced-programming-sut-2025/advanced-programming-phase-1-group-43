package util;

import models.Skill;
import models.enums.SkillType;

/**
 * کلاس کمکی برای محاسبات مربوط به توانایی‌ها
 */
public class SkillUtils {
    /**
     * محاسبه کیفیت محصول بر اساس سطح کشاورزی
     */
    public static int calculateCropQuality(Skill farmingSkill) {
        // هرچه سطح کشاورزی بالاتر باشد، احتمال کیفیت بهتر بیشتر می‌شود
        return farmingSkill.getLevel() > 0 ? 
               (int)(Math.random() * farmingSkill.getLevel()) : 0;
    }

    /**
     * بررسی آیا بازیکن می‌تواند عنصر اضافه دریافت کند (برای استخراج)
     */
    public static boolean canGetExtraResource(Skill miningSkill) {
        return miningSkill.getLevel() >= 2 && Math.random() > 0.7;
    }
}