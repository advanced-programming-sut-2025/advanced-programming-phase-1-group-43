package util;

import models.Recipe;
import models.enums.ItemType;
import java.util.Map;

/**
 * کلاس کمکی برای محاسبات مربوط به ساخت و ساز
 */
public class CraftingUtils {
    /**
     * بررسی آیا بازیکن می‌تواند یک دستورالعمل را یاد بگیرد
     */
    public static boolean canLearnRecipe(Recipe recipe, int farmingLevel, 
                                       int miningLevel, int foragingLevel) {
        // اینجا باید منطق بررسی سطح مهارت پیاده‌سازی شود
        // فعلاً فقط سطح مورد نیاز عمومی را بررسی می‌کند
        return farmingLevel >= recipe.getRequiredSkillLevel() ||
               miningLevel >= recipe.getRequiredSkillLevel() ||
               foragingLevel >= recipe.getRequiredSkillLevel();
    }

    /**
     * محاسبه مواد اولیه مورد نیاز برای چندین ساخت
     */
    public static Map<ItemType, Integer> calculateBulkIngredients(
            Recipe recipe, int times) {
        Map<ItemType, Integer> ingredients = recipe.getIngredients();
        ingredients.replaceAll((k, v) -> v * times);
        return ingredients;
    }
}