package Model;

import models.enums.ItemType;
import java.util.HashMap;
import java.util.Map;

/**
 * مدل یخچال برای نگهداری مواد غذایی
 */
public class Refrigerator {
    private final Map<ItemType, Integer> items;
    private final int capacity;

    public Refrigerator() {
        this.items = new HashMap<>();
        this.capacity = 20; // ظرفیت یخچال
    }

    /**
     * اضافه کردن آیتم به یخچال
     */
    public boolean addItem(ItemType type, int count) {
        if (getTotalItems() + count > capacity) {
            return false;
        }
        items.put(type, items.getOrDefault(type, 0) + count);
        return true;
    }

    /**
     * برداشتن آیتم از یخچال
     */
    public boolean removeItem(ItemType type, int count) {
        if (!items.containsKey(type) || items.get(type) < count) {
            return false;
        }
        items.put(type, items.get(type) - count);
        if (items.get(type) == 0) {
            items.remove(type);
        }
        return true;
    }

    /**
     * بررسی وجود آیتم در یخچال
     */
    public boolean hasItem(ItemType type) {
        return items.containsKey(type) && items.get(type) > 0;
    }

    /**
     * تعداد آیتم خاص در یخچال
     */
    public int getItemCount(ItemType type) {
        return items.getOrDefault(type, 0);
    }

    /**
     * تعداد کل آیتم‌ها در یخچال
     */
    public int getTotalItems() {
        return items.values().stream().mapToInt(Integer::intValue).sum();
    }

    public boolean isFull() {
        return getTotalItems() >= capacity;
    }
}