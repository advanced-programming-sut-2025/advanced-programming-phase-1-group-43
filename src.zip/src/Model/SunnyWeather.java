package Model;

public class SunnyWeather extends Weather{
}
