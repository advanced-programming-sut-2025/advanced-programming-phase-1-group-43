package Model;

public class Tree extends Plant{
    private boolean isChoppable;
}
