package Model;

public class Gift {
    private Item item;
    private int amount;
}
