package Model;

public class Trash {
    public String Type;
}
