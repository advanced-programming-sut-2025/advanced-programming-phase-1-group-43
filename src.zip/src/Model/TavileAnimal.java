package Model;

public class TavileAnimal extends Animal{
}
