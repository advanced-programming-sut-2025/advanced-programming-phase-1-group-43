package Model;

import Model.enums.TerrainType;

public class Tile {
    private int x;
    private int y;
    private TerrainType terrainType;
    public boolean isOccupied() {
        return false;
    }
}

