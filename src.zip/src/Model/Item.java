package Model;

import Model.enums.ItemType;

public class Item {
    private String name;
    private ItemType type;
    private int value;
    private double weight;
}
