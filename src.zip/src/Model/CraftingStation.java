package Model;

import java.util.HashMap;
import java.util.Map;

/**
 * ایستگاه ساخت و ساز در خانه بازیکن
 */
public class CraftingStation {
    private final Map<ItemType, Recipe> recipes;
    private boolean isInHome = false;

    public CraftingStation() {
        this.recipes = new HashMap<>();
        initializeBasicRecipes();
    }

    private void initializeBasicRecipes() {
        // دستورالعمل‌های اولیه
        recipes.put(ItemType.BASIC_HOE, new Recipe(
            ItemType.BASIC_HOE, 1,
            Map.of(ItemType.WOOD, 5, ItemType.STONE, 2),
            true, 0
        ));
        
        recipes.put(ItemType.SCARECROW, new Recipe(
            ItemType.SCARECROW, 1,
            Map.of(ItemType.WOOD, 50, ItemType.COAL, 1),
            false, 2
        ));
    }

    /**
     * یادگیری یک دستورالعمل جدید
     */
    public void learnRecipe(ItemType itemType) {
        Recipe recipe = recipes.get(itemType);
        if (recipe != null) {
            recipes.put(itemType, new Recipe(
                recipe.getResult(),
                recipe.getResultCount(),
                recipe.getIngredients(),
                true,
                recipe.getRequiredSkillLevel()
            ));
        }
    }

    // Getterها
    public Map<ItemType, Recipe> getRecipes() {
        return recipes;
    }

    public boolean isInHome() {
        return isInHome;
    }

    public void setInHome(boolean inHome) {
        isInHome = inHome;
    }
}