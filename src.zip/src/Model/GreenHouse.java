package Model;

public class GreenHouse {
    // some variables

    void build() {

    }
}
