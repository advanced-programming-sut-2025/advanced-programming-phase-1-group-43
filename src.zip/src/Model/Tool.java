package Model;

import Model.enums.ToolType;

public class Tool {
    private String ToolName;
    private int durability;
    private ToolType toolType;
    private int useCost;
    private int toolLevel;

    public void useOn(Tile target) {

    }

    public void upgrade() {

    }


}
