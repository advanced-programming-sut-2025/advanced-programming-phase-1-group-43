package Model;

import models.enums.ToolType;
import models.enums.ToolMaterial;

/**
 * مدل ابزارهای بازی
 */
public class Tool {
    private final ToolType type;
    private ToolMaterial material;
    private int durability;

    public Tool(ToolType type, ToolMaterial material) {
        this.type = type;
        this.material = material;
        this.durability = 100; // دوام اولیه
    }

    /**
     * محاسبه انرژی مصرفی بر اساس جنس ابزار
     */
    public int getEnergyCost() {
        switch (material) {
            case BASIC: return getBaseEnergyCost();
            case COPPER: return getBaseEnergyCost() - 1;
            case IRON: return getBaseEnergyCost() - 2;
            case GOLD: return getBaseEnergyCost() - 3;
            case IRIDIUM: return getBaseEnergyCost() - 4;
            default: return getBaseEnergyCost();
        }
    }

    /**
     * انرژی پایه برای هر نوع ابزار
     */
    private int getBaseEnergyCost() {
        switch (type) {
            case HOE: return 5;
            case PICKAXE: return 5;
            case AXE: return 5;
            case WATERING_CAN: return 5;
            case FISHING_ROD: return 8;
            case SCYTHE: return 2;
            case MILK_PAIL: return 4;
            case SHEARS: return 4;
            default: return 0; // برای ابزارهایی که انرژی مصرف نمی‌کنند
        }
    }

    /**
     * ارتقای ابزار
     */
    public boolean upgrade(ToolMaterial newMaterial) {
        if (newMaterial.ordinal() > material.ordinal()) {
            this.material = newMaterial;
            this.durability = 100; // بازسازی دوام
            return true;
        }
        return false;
    }

    // Getterها
    public ToolType getType() {
        return type;
    }

    public ToolMaterial getMaterial() {
        return material;
    }

    public int getDurability() {
        return durability;
    }

    public String getDisplayName() {
        return material.getPersianName() + " " + type.getPersianName();
    }
}