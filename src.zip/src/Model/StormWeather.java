package Model;

public class StormWeather extends Weather{
}
