package Model;

import models.enums.ItemType;
import java.util.Map;
import models.enums.FoodType;

/**
 * مدل دستورالعمل ساخت یک آیتم
 */
public class Recipe {
    
    private final ItemType result;
    private final int resultCount;
    private final Map<ItemType, Integer> ingredients;
    private final boolean learned;
    private final int requiredSkillLevel;
    
    public Recipe(ItemType result, int resultCount, 
                 Map<ItemType, Integer> ingredients, 
                 boolean learned, int requiredSkillLevel) {
        this.result = result;
        this.resultCount = resultCount;
        this.ingredients = ingredients;
        this.learned = learned;
        this.requiredSkillLevel = requiredSkillLevel;
        this.ingredients = ingredients;

    }

    /**
     * بررسی آیا مواد اولیه کافی برای ساخت وجود دارد
     */
    public boolean canCraft(Player player) {
        if (!learned) return false;
        
        for (Map.Entry<ItemType, Integer> entry : ingredients.entrySet()) {
            if (player.getInventory().getItemCount(entry.getKey()) < entry.getValue()) {
                return false;
            }
        }
        return true;
    }
    public boolean canCook(Player player) {
        if (!learned) return false;
        
        // بررسی مواد در یخچال و اینونتوری
        for (Map.Entry<ItemType, Integer> entry : ingredients.entrySet()) {
            int total = player.getInventory().getItemCount(entry.getKey()) + 
                       player.getRefrigerator().getItemCount(entry.getKey());
            if (total < entry.getValue()) {
                return false;
            }
        }
        return true;
    }
    // Getterها
    
    public ItemType getResult() {
        return result;
    }

    public int getResultCount() {
        return resultCount;
    }

    public Map<ItemType, Integer> getIngredients() {
        return ingredients;
    }

    public boolean isLearned() {
        return learned;
    }

    public int getRequiredSkillLevel() {
        return requiredSkillLevel;
    }
}