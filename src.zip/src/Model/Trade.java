package Model;

public class Trade {
    private Item offeredItem;
    private Item requestedItem;
    private NPC tradePartner;

    public boolean executeTrade() {
        return false;
    }
}
