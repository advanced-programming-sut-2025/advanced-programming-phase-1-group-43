package Model;

import Model.enums.BuildingType;

public class Building {
    private BuildingType buildingType;
    private Tile location;
    private int capacity;

    public void repair() {

    }

    public void build() {

    }
}
