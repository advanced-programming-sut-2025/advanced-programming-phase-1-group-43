package Model;

import models.enums.SkillType;

/**
 * مدل توانایی‌های بازیکن
 */
public class Skill {
    private final SkillType type;
    private int level;
    private int experience;
    private int experienceToNextLevel;

    public Skill(SkillType type) {
        this.type = type;
        this.level = 0;
        this.experience = 0;
        this.experienceToNextLevel = calculateExperienceToNextLevel();
    }

    /**
     * محاسبه تجربه مورد نیاز برای سطح بعدی
     * فرمول: (100 × i) + 50
     */
    private int calculateExperienceToNextLevel() {
        return (100 * (level + 1)) + 50;
    }

    /**
     * افزایش تجربه توانایی
     * @param amount مقدار تجربه که باید اضافه شود
     */
    public void addExperience(int amount) {
        this.experience += amount;
        checkLevelUp();
    }

    /**
     * بررسی ارتقا سطح
     */
    private void checkLevelUp() {
        while (experience >= experienceToNextLevel && level < 4) {
            experience -= experienceToNextLevel;
            level++;
            experienceToNextLevel = calculateExperienceToNextLevel();
            applyLevelUpBenefits();
        }
    }

    /**
     * اعمال مزایای ارتقا سطح
     */
    private void applyLevelUpBenefits() {
        // مزایای خاص هر سطح در سرویس مربوطه پیاده‌سازی می‌شود
        // اینجا فقط یک پیام نمایش می‌دهیم
        System.out.println("سطح " + type.getPersianName() + " به " + level + " ارتقا یافت!");
    }

    // Getterها
    public SkillType getType() {
        return type;
    }

    public int getLevel() {
        return level;
    }

    public int getExperience() {
        return experience;
    }

    public int getExperienceToNextLevel() {
        return experienceToNextLevel;
    }
}