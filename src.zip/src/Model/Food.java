package Model;

import models.enums.BuffType;
import models.enums.FoodType;

/**
 * مدل غذاهای بازی
 */
public class Food {
    private final FoodType type;
    private BuffType buffType;
    private int buffValue;

    public Food(FoodType type) {
        this.type = type;
        // تنظیم باف پیش‌فرض بر اساس نوع غذا
        setDefaultBuff();
    }

    private void setDefaultBuff() {
        switch (type) {
            case SALAD:
                this.buffType = BuffType.FARMING_BOOST;
                this.buffValue = 1;
                break;
            case FISH_MEAL:
                this.buffType = BuffType.ENERGY_BOOST;
                this.buffValue = 20;
                break;
            default:
                this.buffType = null;
                this.buffValue = 0;
        }
    }

    // Getterها
    public FoodType getType() {
        return type;
    }

    public BuffType getBuffType() {
        return buffType;
    }

    public int getBuffValue() {
        return buffValue;
    }

    public String getDisplayName() {
        return type.getPersianName();
    }
}