package Model;

import Model.enums.Season;

import java.time.LocalTime;

public class DateTimeManager {
    private int day;
    private Season season;
    private LocalTime time;

    public void advanceTime(int hours) {

    }

    public void advanceDate(int days) {

    }

    public String getCurrentDateTime() {
        return null;
    }

}
