package Model.enums;

/**
 * انواع توانایی‌های بازی
 */
public enum SkillType {
    FARMING("کشاورزی"),
    MINING("استخراج"),
    FORAGING("طبیعت‌گردی"),
    FISHING("ماهیگیری");

    private final String persianName;

    SkillType(String persianName) {
        this.persianName = persianName;
    }

    public String getPersianName() {
        return persianName;
    }
}