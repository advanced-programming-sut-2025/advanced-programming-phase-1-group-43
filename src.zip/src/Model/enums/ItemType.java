package Model.enums;

public enum ItemType {
    TOOL,
    MATERIAL,
    PRODUCT,
    CONSUMABLE;
}
