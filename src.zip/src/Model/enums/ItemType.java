package Models.enums;

/**
 * انواع آیتم‌های قابل ساخت در بازی
 */
public enum ItemType {
    // مواد اولیه
    WOOD("چوب"),
    STONE("سنگ"),
    COAL("ذغال سنگ"),
    
    // ابزارها
    BASIC_HOE("بیل پایه"),
    COPPER_HOE("بیل مسی"),
    
    // محصولات
    SCARECROW("مترسک"),
    FENCE("حصیر"),
    
    // ماشین‌آلات
    FURNACE("کوره"),
    CHEESE_PRESS("دستگاه پنیرسازی");

    private final String persianName;

    ItemType(String persianName) {
        this.persianName = persianName;
    }

    public String getPersianName() {
        return persianName;
    }
}