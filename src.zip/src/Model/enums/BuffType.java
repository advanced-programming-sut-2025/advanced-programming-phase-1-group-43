package Model.enums;

/**
 * انواع اثرات (باف) غذاها
 */
public enum BuffType {
    FARMING_BOOST("افزایش کشاورزی", 240),
    MINING_BOOST("افزایش استخراج", 240),
    ENERGY_BOOST("افزایش انرژی", 480),
    LUCK_BOOST("افزایش شانس", 180);

    private final String persianName;
    private final int duration; // مدت زمان به دقیقه

    BuffType(String persianName, int duration) {
        this.persianName = persianName;
        this.duration = duration;
    }

    public String getPersianName() {
        return persianName;
    }

    public int getDuration() {
        return duration;
    }
}