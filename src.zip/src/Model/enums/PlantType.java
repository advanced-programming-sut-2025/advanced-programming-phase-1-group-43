package Model.enums;

public enum PlantType {
    CROP,
    TREE,
    FLOWER;
}
