package Model.enums;

public enum WeatherType {
    SUNNY,
    RAIN,
    STORM,
    SNOW;
}
