package Model.enums;

public enum BuildingType {
    GREENHOUSE,
    HOUSE,
    QUARRY,
    CABIN;
}
