package Model.enums;

public enum TerrainType {
    FOREST,
    PLAIN,
    WATER,
    MOUNTAIN;
}
