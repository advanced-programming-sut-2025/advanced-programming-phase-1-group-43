package Model.enums;

/**
 * انواع ابزارهای بازی
 */
public enum ToolType {
    HOE("بیل"),
    PICKAXE("کلنگ"),
    AXE("تبر"),
    WATERING_CAN("ظرف آبیاری"),
    FISHING_ROD("چوب ماهیگیری"),
    SCYTHE("داس"),
    MILK_PAIL("سطل شیر"),
    SHEARS("قیچی"),
    BACKPACK("کوله پشتی"),
    TRASH_CAN("سطل آشغال");

    private final String persianName;

    ToolType(String persianName) {
        this.persianName = persianName;
    }

    public String getPersianName() {
        return persianName;
    }
}