package Model.enums;

public enum ToolType {
    Hoe,
    Pickaxe,
    Watering_Can,
    Fishing_Pole,
    Axe;
}
