package Model.enums;

/**
 * انواع غذاهای قابل پخت در بازی
 */
public enum FoodType {
    SALAD("سالاد", 20),
    SOUP("سوپ", 30),
    BREAD("نان", 15),
    FISH_MEAL("غذای ماهی", 40),
    STEW("خورشت", 50);

    private final String persianName;
    private final int energyRestore;

    FoodType(String persianName, int energyRestore) {
        this.persianName = persianName;
        this.energyRestore = energyRestore;
    }

    public String getPersianName() {
        return persianName;
    }

    public int getEnergyRestore() {
        return energyRestore;
    }
}