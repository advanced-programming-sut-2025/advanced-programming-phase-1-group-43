package Model.enums;

public enum AnimalType {
    COW,
    DOG,
    CHICKEN,
    FISH;
}
