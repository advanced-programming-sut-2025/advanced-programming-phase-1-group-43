package Model.enums;

/**
 * انواع فعالیت‌های بازی که انرژی مصرف می‌کنند
 */
public enum ActivityType {
    DIGGING(10),
    FISHING(8),
    CHOPPING(15),
    MINING(12),
    WALKING(2),
    RUNNING(5),
    WATERING(7),
    DEFAULT(5);

    private final int energyCost;

    ActivityType(int energyCost) {
        this.energyCost = energyCost;
    }

    public int getEnergyCost() {
        return energyCost;
    }
}