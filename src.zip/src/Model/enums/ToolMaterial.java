package Model.enums;

/**
 * مواد مختلف برای ساخت ابزار
 */
public enum ToolMaterial {
    BASIC("پایه", 0),
    COPPER("مس", 2000),
    IRON("آهن", 5000),
    GOLD("طلایی", 10000),
    IRIDIUM("ایریدیوم", 25000);

    private final String persianName;
    private final int upgradeCost;

    ToolMaterial(String persianName, int upgradeCost) {
        this.persianName = persianName;
        this.upgradeCost = upgradeCost;
    }

    public String getPersianName() {
        return persianName;
    }

    public int getUpgradeCost() {
        return upgradeCost;
    }
}