package Model.enums;

public enum Season {
    SPRING,
    SUMMER,
    AUTUMN,
    WINTER;
}
