package Model.enums;

public enum Commmands {
    ;
}
