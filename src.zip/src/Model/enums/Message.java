package Model.enums;

public enum Message {
}
