package Model;

public class Store extends Building {
}
