package Model;

public class GhafasiAnimal extends Animal{
}
