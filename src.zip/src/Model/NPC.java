package Model;

import java.util.List;

public class NPC {
    private String Name;
    private List<String> dialogueSet;
    private int friendShipLevel;
    private Tile location;
    private List<Gift> gifts;

    public String talk() {
        return null;
    }

    public void mission() {

    }

    public void updateFriendship(int amount) {

    }
}
