package Model;

import Model.enums.WeatherType;

public class Weather {
    private WeatherType currentWeather;
    public Weather CurrentWeather;

    public void updateWeather() {
    }
}
