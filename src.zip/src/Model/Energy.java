package Model;

/**
 * مدل انرژی که اطلاعات مربوط به انرژی بازیکن را نگهداری می‌کند
 */
public class Energy {
    private int current;
    private int max;
    private boolean unlimited;
    private boolean hasFainted;

    public Energy() {
        this.max = 200; // سقف انرژی پیش‌فرض
        this.current = this.max; // انرژی اولیه برابر با سقف انرژی
        this.unlimited = false;
        this.hasFainted = false;
    }

    // Getter و Setter ها
    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        if (!unlimited) {
            this.current = Math.min(current, max);
        } else {
            this.current = current;
        }
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
        if (!unlimited) {
            this.current = Math.min(this.current, max);
        }
    }

    public boolean isUnlimited() {
        return unlimited;
    }

    public void setUnlimited(boolean unlimited) {
        this.unlimited = unlimited;
    }

    public boolean hasFainted() {
        return hasFainted;
    }

    public void setFainted(boolean hasFainted) {
        this.hasFainted = hasFainted;
    }

    /**
     * کاهش انرژی
     * @param amount مقدار انرژی که باید کاهش یابد
     * @return true اگر انرژی به صفر رسیده باشد (بازیکن غش کرده)
     */
    public boolean decrease(int amount) {
        if (unlimited) {
            return false;
        }

        current = Math.max(current - amount, 0);
        if (current == 0) {
            hasFainted = true;
            return true;
        }
        return false;
    }

    /**
     * افزایش انرژی
     * @param amount مقدار انرژی که باید افزایش یابد
     */
    public void increase(int amount) {
        if (!unlimited) {
            current = Math.min(current + amount, max);
        }
    }

    /**
     * بازگردانی انرژی برای روز جدید
     */
    public void restoreForNewDay() {
        if (hasFainted) {
            current = (int)(max * 0.75);
            hasFainted = false;
        } else {
            current = max;
        }
    }
}