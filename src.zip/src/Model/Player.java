package Model;
import models.enums.SkillType;
import java.util.EnumMap;
import java.util.Map;
import models.enums.ToolType;
/**
 * کلاس Player که اطلاعات اصلی بازیکن را نگهداری می‌کند
 */
public class Player {
    private String username;
    private Energy energy; // انرژی بازیکن
    private Position position; // موقعیت بازیکن
    private Map<SkillType, Skill> skills;
    private Map<ToolType, Tool> tools;
    private Tool equippedTool;
    private Backpack backpack;
    private CraftingStation craftingStation;
    private Inventory inventory;
    private Refrigerator refrigerator;
    private Map<FoodType, Recipe> recipes;
    private Food activeBuff;
    private boolean isInHome = false;
    public Player(String username) {
        this.username = username;
        this.energy = new Energy();
        this.position = new Position(0, 0); // موقعیت پیش‌فرض
        this.skills = new EnumMap<>(SkillType.class);
        this.tools = new EnumMap<>(ToolType.class);
        this.backpack = new Backpack(12); // ظرفیت اولیه
        this.craftingStation = new CraftingStation();
        this.inventory = new Inventory(12); // ظرفیت اولیه
        this.refrigerator = new Refrigerator();
        this.recipes = new HashMap<>();
        initializeBasicRecipes();
        // ابزارهای اولیه
        initializeBasicTools();
        for (SkillType type : SkillType.values()) {
            skills.put(type, new Skill(type));
        }
    }
    private void initializeBasicRecipes() {
        // دستورالعمل‌های اولیه آشپزی
        recipes.put(FoodType.BREAD, new Recipe(
            FoodType.BREAD,
            Map.of(ItemType.WHEAT, 1),
            true, 0
        ));
    }
    private void initializeBasicTools() {
        tools.put(ToolType.HOE, new Tool(ToolType.HOE, ToolMaterial.BASIC));
        tools.put(ToolType.PICKAXE, new Tool(ToolType.PICKAXE, ToolMaterial.BASIC));
        tools.put(ToolType.AXE, new Tool(ToolType.AXE, ToolMaterial.BASIC));
        tools.put(ToolType.WATERING_CAN, new Tool(ToolType.WATERING_CAN, ToolMaterial.BASIC));
        tools.put(ToolType.SCYTHE, new Tool(ToolType.SCYTHE, ToolMaterial.BASIC));
    }
        // Getter و Setter ها
        public Refrigerator getRefrigerator() {
            return refrigerator;
        }
    
        public Map<FoodType, Recipe> getRecipes() {
            return recipes;
        }
    
        public Food getActiveBuff() {
            return activeBuff;
        }
    
        public void setActiveBuff(Food activeBuff) {
            this.activeBuff = activeBuff;
        }
    
        public boolean isInHome() {
            return isInHome;
        }
    
        public void setInHome(boolean inHome) {
            isInHome = inHome;
        }
    public CraftingStation getCraftingStation() {
        return craftingStation;
    }

    public Inventory getInventory() {
        return inventory;
    }
        public Tool getEquippedTool() {
            return equippedTool;
        }
    
        public Skill getSkill(SkillType type) {
            return skills.get(type);
        }
       public void setEquippedTool(Tool tool) {
        this.equippedTool = tool;
    }

    public Tool getTool(ToolType type) {
        return tools.get(type);
    }

    public Backpack getBackpack() {
        return backpack;
    }
   
    public String getUsername() {
        return username;
    }

    public Energy getEnergy() {
        return energy;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(int x, int y) {
        this.position.setX(x);
        this.position.setY(y);
    }
}