package Model;
import models.enums.SkillType;
import java.util.EnumMap;
import java.util.Map;
/**
 * کلاس Player که اطلاعات اصلی بازیکن را نگهداری می‌کند
 */
public class Player {
    private String username;
    private Energy energy; // انرژی بازیکن
    private Position position; // موقعیت بازیکن
    private Map<SkillType, Skill> skills;
    public Player(String username) {
        this.username = username;
        this.energy = new Energy();
        this.position = new Position(0, 0); // موقعیت پیش‌فرض
        this.skills = new EnumMap<>(SkillType.class);
        for (SkillType type : SkillType.values()) {
            skills.put(type, new Skill(type));
        }
    }
        // Getterها
        public Skill getSkill(SkillType type) {
            return skills.get(type);
        }
    
    // Getter و Setter ها
    public String getUsername() {
        return username;
    }

    public Energy getEnergy() {
        return energy;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(int x, int y) {
        this.position.setX(x);
        this.position.setY(y);
    }
}