package Model;

public class RainyWeather extends Weather{
}
