package Model;
import java.util.Map;

public class Inventory {
    private Map<Item, Integer> items;

    public void addItem(Item item, int count) {

    }

    public void removeItem(Item item, int count) {

    }

    public void showInventory() {

    }
}
