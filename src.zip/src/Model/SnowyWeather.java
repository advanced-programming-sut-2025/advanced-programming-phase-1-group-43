package Model;

public class SnowyWeather extends Weather{
}
