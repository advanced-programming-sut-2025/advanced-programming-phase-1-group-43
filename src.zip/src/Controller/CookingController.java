package Controller;

import services.CookingService;
import models.Player;
import models.enums.FoodType;
import models.enums.ItemType;

/**
 * کنترلر مدیریت دستورات مربوط به آشپزی
 */
public class CookingController {
    private final CookingService cookingService;

    public CookingController(Player player, EnergyService energyService, 
                           InventoryService inventoryService) {
        this.cookingService = new CookingService(player, energyService, inventoryService);
    }

    /**
     * پردازش دستورات آشپزی
     * @param command دستور وارد شده
     */
    public String handleCookingCommand(String command) {
        String[] parts = command.split(" ");
        
        if (parts.length < 2) {
            return "دستور نامعتبر. فرمت صحیح: cooking [refrigerator|show|prepare|eat|learn]";
        }

        switch (parts[1]) {
            case "refrigerator":
                return handleRefrigeratorCommand(parts);
                
            case "show":
                if (parts.length < 3 || !parts[2].equals("recipes")) {
                    return "فرمت دستور نامعتبر. فرمت صحیح: cooking show recipes";
                }
                return cookingService.showRecipes();
                
            case "prepare":
                if (parts.length < 3) {
                    return "نام غذا را وارد کنید";
                }
                try {
                    FoodType foodType = FoodType.valueOf(parts[2].toUpperCase());
                    return cookingService.prepareFood(foodType);
                } catch (IllegalArgumentException e) {
                    return "غذای نامعتبر";
                }
                
            case "eat":
                if (parts.length < 3) {
                    return "نام غذا را وارد کنید";
                }
                try {
                    FoodType foodType = FoodType.valueOf(parts[2].toUpperCase());
                    return cookingService.eatFood(foodType);
                } catch (IllegalArgumentException e) {
                    return "غذای نامعتبر";
                }
                
            case "learn":
                if (parts.length < 3) {
                    return "نام غذا را وارد کنید";
                }
                try {
                    FoodType foodType = FoodType.valueOf(parts[2].toUpperCase());
                    return cookingService.learnRecipe(foodType);
                } catch (IllegalArgumentException e) {
                    return "غذای نامعتبر";
                }
                
            default:
                return "دستور نامعتبر";
        }
    }

    private String handleRefrigeratorCommand(String[] parts) {
        if (parts.length < 4) {
            return "فرمت دستور نامعتبر. فرمت صحیح: cooking refrigerator [put/pick] <item>";
        }

        try {
            ItemType item = ItemType.valueOf(parts[3].toUpperCase());
            int count = 1; // مقدار پیش‌فرض
            
            if (parts.length > 4) {
                try {
                    count = Integer.parseInt(parts[4]);
                } catch (NumberFormatException e) {
                    return "تعداد باید عدد باشد";
                }
            }

            if (parts[2].equals("put")) {
                return cookingService.putInRefrigerator(item, count);
            } else if (parts[2].equals("pick")) {
                return cookingService.pickFromRefrigerator(item, count);
            } else {
                return "عمل نامعتبر (باید put یا pick باشد)";
            }
        } catch (IllegalArgumentException e) {
            return "آیتم نامعتبر";
        }
    }
}