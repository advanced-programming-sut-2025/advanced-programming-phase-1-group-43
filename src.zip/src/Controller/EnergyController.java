package Controller;

import services.EnergyService;
import models.Player;

/**
 * کنترلر مدیریت دستورات مربوط به انرژی
 */
public class EnergyController {
    private final EnergyService energyService;

    public EnergyController(Player player) {
        this.energyService = new EnergyService(player);
    }

    /**
     * نمایش انرژی فعلی بازیکن
     */
    public String showEnergy() {
        var energy = energyService.getPlayer().getEnergy();
        return "انرژی فعلی: " + energy.getCurrent() + "/" + energy.getMax() + 
               (energy.isUnlimited() ? " (نامحدود)" : "");
    }

    /**
     * پردازش دستورات انرژی
     * @param command دستور وارد شده
     */
    public String handleEnergyCommand(String command) {
        String[] parts = command.split(" ");
        
        if (parts.length < 2) {
            return "دستور نامعتبر. فرمت صحیح: energy [show|set|unlimited]";
        }

        switch (parts[1]) {
            case "show":
                return showEnergy();
                
            case "set":
                if (parts.length < 4 || !parts[2].equals("-v")) {
                    return "فرمت دستور نامعتبر. فرمت صحیح: energy set -v <value>";
                }
                try {
                    int value = Integer.parseInt(parts[3]);
                    energyService.setEnergy(value);
                    return "انرژی با موفقیت تنظیم شد: " + value;
                } catch (NumberFormatException e) {
                    return "مقدار انرژی باید یک عدد باشد.";
                }
                
            case "unlimited":
                energyService.setUnlimitedEnergy(true);
                return "حالت انرژی نامحدود فعال شد.";
                
            default:
                return "دستور نامعتبر. دستورات موجود: show, set, unlimited";
        }
    }
}