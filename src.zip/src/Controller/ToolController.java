package Controller;

import services.ToolService;
import models.Player;
import models.enums.ToolMaterial;

/**
 * کنترلر مدیریت دستورات مربوط به ابزارها
 */
public class ToolController {
    private final ToolService toolService;

    public ToolController(Player player) {
        this.toolService = new ToolService(player);
    }

    /**
     * پردازش دستورات ابزارها
     * @param command دستور وارد شده
     */
    public String handleToolCommand(String command) {
        String[] parts = command.split(" ");
        
        if (parts.length < 2) {
            return "دستور نامعتبر. فرمت صحیح: tools [equip|show|upgrade|use]";
        }

        switch (parts[1]) {
            case "equip":
                if (parts.length < 3) {
                    return "نام ابزار را وارد کنید";
                }
                return toolService.equipTool(parts[2]);
                
            case "show":
                if (parts.length < 3) {
                    return "نوع نمایش را مشخص کنید (current|available)";
                }
                if (parts[2].equals("current")) {
                    return toolService.showCurrentTool();
                } else if (parts[2].equals("available")) {
                    return toolService.showAvailableTools();
                } else {
                    return "نوع نمایش نامعتبر";
                }
                
            case "upgrade":
                if (parts.length < 4) {
                    return "نام ابزار و جنس جدید را وارد کنید";
                }
                try {
                    ToolMaterial material = ToolMaterial.valueOf(parts[3].toUpperCase());
                    return toolService.upgradeTool(parts[2], material);
                } catch (IllegalArgumentException e) {
                    return "جنس ابزار نامعتبر";
                }
                
            case "use":
                if (parts.length < 4 || !parts[2].equals("-d")) {
                    return "جهت استفاده را وارد کنید (use -d <direction>)";
                }
                return toolService.useTool(parts[3]);
                
            default:
                return "دستور نامعتبر";
        }
    }
}