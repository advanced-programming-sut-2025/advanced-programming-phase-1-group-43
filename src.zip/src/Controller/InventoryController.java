package Controller;

public class InventoryController {
}
