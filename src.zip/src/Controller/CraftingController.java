package Controller;

import services.CraftingService;
import models.Player;

/**
 * کنترلر مدیریت دستورات مربوط به ساخت و ساز
 */
public class CraftingController {
    private final CraftingService craftingService;

    public CraftingController(Player player, EnergyService energyService) {
        this.craftingService = new CraftingService(player, energyService);
    }

    /**
     * پردازش دستورات ساخت و ساز
     * @param command دستور وارد شده
     */
    public String handleCraftingCommand(String command) {
        String[] parts = command.split(" ");
        
        if (parts.length < 2) {
            return "دستور نامعتبر. فرمت صحیح: crafting [show|craft|learn|place|cheat]";
        }

        switch (parts[1]) {
            case "show":
                if (parts.length < 3 || !parts[2].equals("recipes")) {
                    return "فرمت دستور نامعتبر. فرمت صحیح: crafting show recipes";
                }
                return craftingService.showRecipes();
                
            case "craft":
                if (parts.length < 3) {
                    return "نام آیتم را وارد کنید";
                }
                return craftingService.craftItem(parts[2]);
                
            case "learn":
                if (parts.length < 3) {
                    return "نام آیتم را وارد کنید";
                }
                return craftingService.learnRecipe(parts[2]);
                
            case "place":
                if (parts.length < 6 || !parts[2].equals("item") || 
                    !parts[3].equals("-n") || !parts[5].equals("-d")) {
                    return "فرمت دستور نامعتبر. فرمت صحیح: crafting place item -n <name> -d <direction>";
                }
                return craftingService.placeItem(parts[4], parts[6]);
                
            case "cheat":
                if (parts.length < 8 || !parts[2].equals("add") || 
                    !parts[3].equals("item") || !parts[4].equals("-n") || 
                    !parts[6].equals("-c")) {
                    return "فرمت دستور نامعتبر. فرمت صحیح: crafting cheat add item -n <name> -c <count>";
                }
                try {
                    int count = Integer.parseInt(parts[7]);
                    return craftingService.cheatAddItem(parts[5], count);
                } catch (NumberFormatException e) {
                    return "تعداد باید یک عدد باشد";
                }
                
            default:
                return "دستور نامعتبر";
        }
    }
}