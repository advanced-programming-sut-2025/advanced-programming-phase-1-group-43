package View;

public class NPCview {
}
