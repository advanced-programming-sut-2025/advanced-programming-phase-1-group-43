package View;

public class StatusView {
}
