package io.github.some_example_name.service;

import io.github.some_example_name.Model.Player;

import io.github.some_example_name.Model.*;

import java.util.Map;
import java.util.Optional;

public class InventoryService {
    public boolean hasItem(Player player, String itemId, int quantity) {
        return player.getInventory().getItemCount(itemId) >= quantity;
    }

    public boolean removeItem(Player player, String itemId, int quantity) {
        if (hasItem(player, itemId, quantity)) {
            player.getInventory().removeItem(itemId, quantity);
            return true;
        }
        return false;
    }
    /**
     * Gets the ID of an item from the player's inventory
     * @param player The player whose inventory to check
     * @param itemId The ID of the item to find
     * @return Optional containing the item ID if found, empty otherwise
     */
    public Optional<String> getItemId(Player player, String itemId) {
        return Optional.ofNullable(player.getInventory().getItem(itemId))
            .map(Item::getId);
    }

    // Alternative version that returns the Item object with its ID
    public Optional<Item> getItemById(Player player, String itemId) {
        Item item = player.getInventory().getItem(itemId);
        return Optional.ofNullable(item);
    }
    public boolean addItem(Player player, Item item) {
        return player.getInventory().addItem(item.getId(), 1);
    }

    public <T extends Item> Optional<T> getItem(Player player, String itemId, Class<T> itemClass) {
        Item item = player.getInventory().getItem(itemId);
        if (item != null && itemClass.isInstance(item)) {
            return Optional.of(itemClass.cast(item));
        }
        return Optional.empty();
    }

    public boolean isFull(Player player) {
        return player.getInventory().isFull();
    }

    public boolean hasItem(Player player, String itemId) {
        return true;
    }


}
