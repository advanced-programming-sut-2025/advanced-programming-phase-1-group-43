package io.github.some_example_name.Model;



import io.github.some_example_name.Model.enums.SkillType;

/**
 * مدل توانایی‌های بازیکن
 */

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Skill implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum SkillType {
        FARMING,      // کشاورزی
        MINING,       // استخراج
        FORAGING,     // طبیعت گردی
        FISHING       // ماهیگیری
    }

    private static final int MAX_LEVEL = 4;
    private static final int BASE_XP = 50;

    private SkillType type;
    private int level;
    private int experience;
    private int experienceToNextLevel;
    private transient User user;

    public Skill(SkillType type, User user) {
        this.type = type;
        this.user = user;
        this.level = 0;
        this.experience = 0;
        calculateNextLevelXP();
    }

    public void addExperience(int amount) {
        if (level >= MAX_LEVEL) return;

        experience += amount;
        while (experience >= experienceToNextLevel && level < MAX_LEVEL) {
            levelUp();
        }
    }

    private void levelUp() {
        level++;
        experience -= experienceToNextLevel;
        calculateNextLevelXP();
        unlockRecipes();
    }

    private void calculateNextLevelXP() {
        if (level >= MAX_LEVEL) {
            experienceToNextLevel = Integer.MAX_VALUE;
        } else {
            experienceToNextLevel = (level + 1) * BASE_XP * 2;
        }
    }

    private void unlockRecipes() {
        // باز کردن دستورالعمل‌های جدید بر اساس سطح مهارت
        user.getFarm().unlockRecipesForSkill(type, level);
    }

    public String show() {
        if (level >= MAX_LEVEL) {
            return String.format("%s: Level %d (MAX)", type.name(), level);
        }
        return String.format("%s: Level %d (%d/%d XP)",
            type.name(), level, experience, experienceToNextLevel);
    }

    // Getters
    public int getLevel() { return level; }
    public int getExperience() { return experience; }
    public SkillType getType() { return type; }
}
