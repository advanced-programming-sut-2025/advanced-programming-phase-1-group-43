package io.github.some_example_name.Model;

import java.time.LocalDateTime;

public class Interaction {
    private final String type; // e.g., "chat", "gift", "hug"
    private final LocalDateTime timestamp;

    public Interaction(String type) {
        this.type = type;
        this.timestamp = LocalDateTime.now();
    }

    public String getType() {
        return type;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
