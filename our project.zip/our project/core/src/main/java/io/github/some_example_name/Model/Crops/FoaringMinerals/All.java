package io.github.some_example_name.Model.Crops.FoaringMinerals;

public class All {
    public class Quartz {
        public static final int SELL_PRICE = 25;
    }

    public class EarthCrystal {
        public static final int SELL_PRICE = 50;
    }

    public class FrozenTear {
        public static final int SELL_PRICE = 75;
    }

    public class FireQuartz {
        public static final int SELL_PRICE = 100;
    }

    public class Emerald {
        public static final int SELL_PRICE = 250;
    }

    public class Aquamarine {
        public static final int SELL_PRICE = 180;
    }

    public class Ruby {
        public static final int SELL_PRICE = 250;
    }

    public class Amethyst {
        public static final int SELL_PRICE = 100;
    }

    public class Topaz {
        public static final int SELL_PRICE = 80;
    }

    public class Jade {
        public static final int SELL_PRICE = 200;
    }

    public class Diamond {
        public static final int SELL_PRICE = 750;
    }

    public class PrismaticShard {
        public static final int SELL_PRICE = 2000;
    }

    public class Copper {
        public static final int SELL_PRICE = 5;
    }

    public class Iron {
        public static final int SELL_PRICE = 10;
    }

    public class Gold {
        public static final int SELL_PRICE = 25;
    }

    public class Iriduim {
        public static final int SELL_PRICE = 100;
    }

    public class Coal {
        public static final int SELL_PRICE = 15;
    }

}
