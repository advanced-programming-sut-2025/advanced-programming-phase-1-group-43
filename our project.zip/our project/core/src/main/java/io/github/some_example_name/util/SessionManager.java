package io.github.some_example_name.util;



import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import java.util.Optional;



public class SessionManager {
    private static final Path SESSION_FILE = Paths.get("session.txt");

    public static void save(String username) {
        try {
            Path parent = SESSION_FILE.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.write(SESSION_FILE, username.getBytes(),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save session", e);
        }
    }

    public static Optional<String> load() {
        if (!Files.exists(SESSION_FILE)) {
            return Optional.empty();
        }
        try {
            return Optional.of(new String(Files.readAllBytes(SESSION_FILE)));
        } catch (IOException e) {
            try { Files.deleteIfExists(SESSION_FILE); } catch (IOException ignored) {}
            return Optional.empty();
        }
    }

    public static void clear() throws IOException {
        try {
            Files.deleteIfExists(SESSION_FILE);
        } catch (IOException e) {
            throw new RuntimeException("Failed to clear session", e);
        }
    }
}
