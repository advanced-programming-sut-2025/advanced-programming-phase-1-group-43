package io.github.some_example_name.Controller;
import io.github.some_example_name.Model.CookingResult;
import io.github.some_example_name.service.CookingService;

public class CookingController {
    private static final String COOK_PREFIX = "cook ";
    private static final String EAT_PREFIX = "eat ";
    private static final String LEARN_PREFIX = "learn recipe ";

    private final CookingService cookingService;

    public CookingController(CookingService cookingService) {
        this.cookingService = cookingService;
    }

    public String handleCommand(String input) {
        if (input.startsWith(COOK_PREFIX)) {
            String recipeId = input.substring(COOK_PREFIX.length()).trim();
            return handleCookCommand(recipeId);
        }
        else if (input.startsWith(EAT_PREFIX)) {
            String foodId = input.substring(EAT_PREFIX.length()).trim();
            return handleEatCommand(foodId);
        }
        else if (input.startsWith(LEARN_PREFIX)) {
            String recipeId = input.substring(LEARN_PREFIX.length()).trim();
            return handleLearnCommand(recipeId);
        }
        return "Unknown cooking command";
    }

    private String handleCookCommand(String recipeId) {
        CookingResult result = cookingService.prepareFood(recipeId);
        if (result.isSuccess()) {
            return "Cooked: " + result.getFood().getName();
        }
        return "Cooking failed: " + result.getErrorMessage();
    }

    private String handleEatCommand(String foodId) {
        EatingResult result = cookingService.eatFood(foodId);
        if (result.isSuccess()) {
            return "Ate: " + result.getFood().getName() +
                ". Energy restored: " + result.getFood().getEnergyRestore();
        }
        return "Eating failed: " + result.getErrorMessage();
    }

    private String handleLearnCommand(String recipeId) {
        LearningResult result = cookingService.learnRecipe(recipeId);
        if (result.isSuccess()) {
            return "Learned recipe: " + result.getRecipe().getName();
        }
        return "Learning failed: " + result.getErrorMessage();
    }
}
