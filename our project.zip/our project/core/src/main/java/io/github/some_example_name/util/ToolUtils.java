package io.github.some_example_name.util;
// 5 - 12 - بررسی توانایی ابزار برای استفاده روی بلوک خاص (تأثیر ابزار)
// 5 - بیل
// 6 - کلنگ
// 7 - تبر
// 8 - ظرف آبیاری
// 10 - داس
import io.github.some_example_name.Model.Tool;
import io.github.some_example_name.Model.enums.ToolType;
public class ToolUtils {
    public static boolean canUseToolOnTile(Tool tool, String tileType) {
        switch (tool.getType()) {
            case HOE:
                return tileType.equals("SOIL") || tileType.equals("GRASS");
            case PICKAXE:
                return tileType.equals("ROCK") || tileType.equals("STONE");
            case AXE:
                return tileType.equals("TREE") || tileType.equals("LOG");
            case WATERING_CAN:
                return tileType.equals("CROP") || tileType.equals("SOIL");
            case SCYTHE:
                return tileType.equals("CROP") || tileType.equals("GRASS");
            default:
                return false;
        }
    }

    public static String getToolEffect(Tool tool) {
        switch (tool.getType()) {
            case HOE: return "Tills the soil for planting";
            case PICKAXE: return "Breaks rocks and stones";
            case AXE: return "Chops trees and logs";
            case WATERING_CAN: return "Waters crops";
            case SCYTHE: return "Harvests crops and cuts grass";
            default: return "No special effect";
        }
    }
}
