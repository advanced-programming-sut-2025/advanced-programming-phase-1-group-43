package io.github.some_example_name.Controller;



import io.github.some_example_name.Model.User;
import io.github.some_example_name.Model.enums.SkillType;
import io.github.some_example_name.service.SkillService;
import io.github.some_example_name.Model.Player;
import io.github.some_example_name.Model.User;
import io.github.some_example_name.Model.Skill;
/**
 * کنترلر مدیریت دستورات مربوط به توانایی‌ها
 */
public class SkillController {
    private final SkillService skillService;
    private User user;
    public SkillController(Player player) {
        this.skillService = new SkillService(player);
        this.user = user;
    }
    public void handle(String cmd) {
        if (cmd.equals("skills show")) {
            System.out.println(user.showSkills());
        } else {
            System.out.println("Invalid skill command");
        }
    }
    /**
     * نمایش اطلاعات توانایی‌ها
     */
    public String showSkills() {
        return skillService.showSkills();
    }

    /**
     * پردازش رویدادهای مربوط به توانایی‌ها
     * @param skillType نوع توانایی
     * @param actionType نوع عمل (مثلاً برداشت محصول، استخراج و...)
     */
    public String handleSkillAction(String skillType, String actionType) {


        try {
            SkillType type = SkillType.valueOf(skillType.toUpperCase());

            switch (type) {
                case FARMING:
                    skillService.addFarmingExperience();
                    return "تجربه کشاورزی افزایش یافت";
                case MINING:
                    skillService.addMiningExperience();
                    return "تجربه استخراج افزایش یافت";
                case FORAGING:
                    skillService.addForagingExperience();
                    return "تجربه طبیعت‌گردی افزایش یافت";
                case FISHING:
                    skillService.addFishingExperience();
                    return "تجربه ماهیگیری افزایش یافت";
                default:
                    return "نوع توانایی نامعتبر";
            }
        } catch (IllegalArgumentException e) {
            return "نوع توانایی نامعتبر";
        }
    }
}
