package io.github.some_example_name.View;

public class AppView {
    public void Run(){

    }
}
