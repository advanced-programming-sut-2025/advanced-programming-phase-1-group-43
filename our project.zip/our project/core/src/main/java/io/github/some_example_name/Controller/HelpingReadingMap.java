package io.github.some_example_name.Controller;

public class HelpingReadingMap {
    public void printHelpingReadingMap() {
        System.out.println("For Cottage : C");
        System.out.println("For Lake : L");
        System.out.println("For GreenHouse : G");
        System.out.println("For StoneMining : M");
        System.out.println("For Trees : T");
        System.out.println("For Stone : S");
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
    }
}
