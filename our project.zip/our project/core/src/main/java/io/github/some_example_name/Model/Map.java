package io.github.some_example_name.Model;

import java.util.List;

public class Map {
    private Tile tiles;
    private List<Model.Building> buildings;
    private List<NPC> npcs;
    private List<Model.Animal> animals;
    private List<Plant> plants;

    public Tile getTile(int x, int y) {

        return null;
    }
}
