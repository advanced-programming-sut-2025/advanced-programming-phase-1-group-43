package io.github.some_example_name.Model.enums;

public enum ToolMaterial {
    BASIC,      // اولیه
    COPPER,     // مس
    IRON,       // آهن
    GOLD,       // طلا
    IRIDIUM     // ایریدیوم

}
