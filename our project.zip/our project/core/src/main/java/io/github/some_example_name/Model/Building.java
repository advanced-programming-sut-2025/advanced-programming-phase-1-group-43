package io.github.some_example_name.Model;

import Model.enums.BuildingType;

public class Building {
    private BuildingType buildingType;
    private Tile location;
    private int capacity;

    public void repair() {

    }

    public void build() {

    }
}
