package io.github.some_example_name.Model;

public class Stone {
    public int x;
    public int y;
    public Stone(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
