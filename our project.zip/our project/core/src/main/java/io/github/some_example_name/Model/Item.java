package io.github.some_example_name.Model;

import io.github.some_example_name.Model.enums.ItemType;


public class Item {
    private final String id;
    private final String name;
    private final ItemType type;
    private int quantity;
    public Item(String id, String name, ItemType type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    /**
     * Gets the unique identifier of this item
     * @return The item's ID string
     */
    public String getId() {
        return this.id;
    }

    // Other getters
    public String getName() {
        return name;
    }

    public ItemType getType() {
        return type;
    }
    public int getQuantity() {
        return quantity;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Item)) return false;
        Item item = (Item) o;
        return id.equals(item.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
