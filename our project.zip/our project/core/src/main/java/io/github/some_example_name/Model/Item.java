package io.github.some_example_name.Model;

import Model.enums.ItemType;

public class Item {
    private String name;
    private ItemType type;
    private int value;
    private double weight;
}
