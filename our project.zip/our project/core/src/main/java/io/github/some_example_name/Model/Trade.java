package io.github.some_example_name.Model;

public class Trade {
    private Model.Item offeredItem;
    private Model.Item requestedItem;
    private Model.NPC tradePartner;

    public boolean executeTrade() {
        return false;
    }
}
