package io.github.some_example_name.Model.enums;


/**
 * انواع توانایی‌های بازی
 */
public enum SkillType {
    FARMING("Farming"),
    MINING("Mining"),
    FORAGING("Foraging"),
    FISHING("Fishing"),;

    private final String persianName;

    SkillType(String persianName) {
        this.persianName = persianName;
    }

    public String getPersianName() {
        return persianName;
    }
}
