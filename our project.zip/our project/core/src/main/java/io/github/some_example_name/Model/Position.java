package io.github.some_example_name.Model;


public class Position {
    private int x;
    private int y;

    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public static Position fromString(String positionStr) throws IllegalArgumentException {
        try {
            String[] parts = positionStr.split(",");
            if (parts.length != 2) {
                throw new IllegalArgumentException("Position must be in format 'x,y'");
            }
            int x = Integer.parseInt(parts[0].trim());
            int y = Integer.parseInt(parts[1].trim());
            return new Position(x, y);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Position coordinates must be integers");
        }
    }
    // Getter و Setter ها
    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
}
