package io.github.some_example_name.Model;

import java.util.HashMap;
import java.util.Map;
public class Refrigerator {
    private final Map<String, Integer> contents;
    private final int capacity;

    public Refrigerator(int capacity) {
        this.contents = new HashMap<>();
        this.capacity = capacity;
    }

    public boolean addItem(String itemId, int quantity) {
        int current = contents.getOrDefault(itemId, 0);
        if (getTotalItems() + quantity > capacity) {
            return false;
        }
        contents.put(itemId, current + quantity);
        return true;
    }

    public boolean removeItem(String itemId, int quantity) {
        int current = contents.getOrDefault(itemId, 0);
        if (current < quantity) {
            return false;
        }
        contents.put(itemId, current - quantity);
        return true;
    }

    public boolean hasItem(String itemId, int quantity) {
        return contents.getOrDefault(itemId, 0) >= quantity;
    }

    private int getTotalItems() {
        return contents.values().stream().mapToInt(Integer::intValue).sum();
    }

    // Getters
    public Map<String, Integer> getContents() { return contents; }
    public int getCapacity() { return capacity; }
}
