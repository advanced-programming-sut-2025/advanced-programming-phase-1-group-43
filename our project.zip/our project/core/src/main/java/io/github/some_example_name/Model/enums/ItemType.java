package io.github.some_example_name.Model.enums;

public enum ItemType {
    MATERIAL,
    TOOL,
    WHEAT,
    CROP,
    CONSUMABLE,
    FURNITURE,
    DECORATION
}
