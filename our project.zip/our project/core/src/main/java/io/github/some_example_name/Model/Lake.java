package io.github.some_example_name.Model;

public class Lake {
    public int FirstX;
    public int FirstY;
    public int SecondX;
    public int SecondY;

    public Lake(int firstX, int secondX, int firstY, int secondY) {
        FirstX = firstX;
        SecondX = secondX;
        FirstY = firstY;
        SecondY = secondY;
    }
}
