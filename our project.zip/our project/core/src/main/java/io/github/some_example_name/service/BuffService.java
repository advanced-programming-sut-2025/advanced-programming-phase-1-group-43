package io.github.some_example_name.service;

import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.BuffType;

import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.BuffType;

import java.util.List;

public class BuffService {
    public void applyBuff(Player player, BuffType type, int durationMinutes) {
        // Remove existing buff of same type
        removeBuffOfType(player.getActiveBuffs(), type);

        // Apply new buff
        Buff newBuff = new Buff(type, durationMinutes);
        player.getActiveBuffs().add(newBuff);

        // Apply immediate effects
        applyImmediateEffects(player, type);
    }

    private void removeBuffOfType(List<Buff> buffs, BuffType type) {
        buffs.removeIf(b -> b.getType() == type);
    }

    private void applyImmediateEffects(Player player, BuffType type) {
        switch (type) {
            case ENERGY_BOOST:
                player.getEnergy().restore(20);
                break;
            case SKILL_BOOST:
                applySkillBoost(player);
                break;
            case HEALTH_REGEN:
                // Implement health regeneration logic
                break;
            case LUCK_BOOST:
                // Implement luck boost logic
                break;
        }
    }

    private void applySkillBoost(Player player) {
        // Temporary skill increase logic
        // Example: increase all skill levels by 1 while buff is active
    }

    public void updateBuffs(Player player, long minutesPassed) {
        List<Buff> buffs = player.getActiveBuffs();

        // Process each buff
        for (Buff buff : buffs) {
            buff.reduceDuration(minutesPassed);
            if (buff.getRemainingDuration() <= 0) {
                removeBuffEffects(player, buff.getType());
            }
        }

        // Remove expired buffs
        buffs.removeIf(b -> b.getRemainingDuration() <= 0);
    }

    private void removeBuffEffects(Player player, BuffType type) {
        switch (type) {
            case SKILL_BOOST:
                // Revert skill boost effects
                break;
            // Handle other buff type reversions
        }
    }

    public boolean hasBuff(Player player, BuffType type) {
        return player.getActiveBuffs().stream()
            .anyMatch(b -> b.getType() == type);
    }
}
