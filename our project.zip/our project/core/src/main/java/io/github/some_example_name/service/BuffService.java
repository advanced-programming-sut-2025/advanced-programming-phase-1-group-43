package io.github.some_example_name.service;

import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.BuffType;
public class BuffService {
    public void applyBuff(Player player, BuffType type, int durationMinutes) {
        // Remove existing buff of same type
        player.getActiveBuffs().removeIf(b -> b.getType() == type);

        // Apply new buff
        Buff newBuff = new Buff(type, durationMinutes);
        player.getActiveBuffs().add(newBuff);

        // Apply immediate effects
        applyImmediateEffects(player, type);
    }

    private void applyImmediateEffects(Player player, BuffType type) {
        switch (type) {
            case ENERGY_BOOST:
                player.getEnergy().restore(20);
                break;
            case SKILL_BOOST:
                // Temporary skill increase
                break;
            // Other buff types
        }
    }

    public void updateBuffs(Player player, long minutesPassed) {
        player.getActiveBuffs().forEach(buff -> {
            buff.reduceDuration(minutesPassed);
            if (buff.getRemainingDuration() <= 0) {
                removeBuffEffects(player, buff.getType());
            }
        });
        player.getActiveBuffs().removeIf(b -> b.getRemainingDuration() <= 0);
    }

    private void removeBuffEffects(Player player, BuffType type) {
        // Revert any temporary modifications
    }
}
