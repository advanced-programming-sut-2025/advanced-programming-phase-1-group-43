package io.github.some_example_name.util;

import io.github.some_example_name.Model.enums.ActivityType;

/**
 * کلاس کمکی برای محاسبات مربوط به انرژی
 */
public class EnergyUtils {
    /**
     * محاسبه انرژی مورد نیاز برای رسیدن به حداکثر انرژی
     * @param current انرژی فعلی
     * @param max انرژی حداکثر
     * @return مقدار انرژی مورد نیاز برای پر شدن
     */
    public static int calculateEnergyToFull(int current, int max) {
        return Math.max(0, max - current);
    }

    /**
     * بررسی آیا فعالیت باعث غش کردن بازیکن می‌شود
     * @param current انرژی فعلی
     * @param activityType نوع فعالیت
     * @return true اگر فعالیت باعث غش کردن شود
     */
    public static boolean willCauseFainting(int current, ActivityType activityType) {
        return current <= activityType.getEnergyCost();
    }
}
