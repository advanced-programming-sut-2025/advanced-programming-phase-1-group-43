package io.github.some_example_name.service;



import io.github.some_example_name.Model.Player;
import io.github.some_example_name.Model.enums.SkillType;

/**
 * سرویس مدیریت توانایی‌های بازیکن
 */
public class SkillService {
    private final Player player;

    public SkillService(Player player) {
        this.player = player;
    }

    // ========== کشاورزی ==========
    /**
     * افزایش تجربه کشاورزی پس از برداشت محصول
     * (5 واحد افزایش XP به ازای برداشت محصول)
     */
    public void addFarmingExperience() {
        player.getSkill(SkillType.FARMING).addExperience(5);
    }

    // ========== استخراج ==========
    /**
     * افزایش تجربه استخراج پس از نابودی سنگ
     * (10 واحد افزایش XP به ازای هر نابودی سنگ)
     */
    public void addMiningExperience() {
        Skill mining = player.getSkill(SkillType.MINING);
        mining.addExperience(10);

        // اگر سطح 2 یا بالاتر باشد، شانس گرفتن عنصر اضافه
        if (mining.getLevel() >= 2) {
            // این بخش به سیستم آیتم‌ها وابسته است
            // در اینجا فقط یک پیام نمایش می‌دهیم
            System.out.println("شما یک کانی اضافه دریافت کردید!");
        }
    }

    // ========== طبیعت‌گردی ==========
    /**
     * افزایش تجربه طبیعت‌گردی پس از جمع‌آوری از طبیعت
     * (10 واحد افزایش XP به ازای هر عنصر جمع‌آوری شده)
     */
    public void addForagingExperience() {
        player.getSkill(SkillType.FORAGING).addExperience(10);
    }

    // ========== ماهیگیری ==========
    /**
     * افزایش تجربه ماهیگیری پس از گرفتن ماهی
     * (5 واحد افزایش XP به ازای هر ماهی گرفته شده)
     */
    public void addFishingExperience() {
        player.getSkill(SkillType.FISHING).addExperience(5);
    }

    /**
     * نمایش اطلاعات تمام توانایی‌ها
     */
    public String showSkills() {
        StringBuilder sb = new StringBuilder();
        for (SkillType type : SkillType.values()) {
            Skill skill = player.getSkill(type);
            sb.append(String.format("%s: سطح %d (XP: %d/%d)%n",
                type.getPersianName(),
                skill.getLevel(),
                skill.getExperience(),
                skill.getExperienceToNextLevel()));
        }
        return sb.toString();
    }
}
