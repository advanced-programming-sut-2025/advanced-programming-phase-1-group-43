package io.github.some_example_name.Model;

import io.github.some_example_name.Model.enums.ToolType;


import io.github.some_example_name.Model.enums.ToolMaterial;
import io.github.some_example_name.Model.enums.ToolType;

import static io.github.some_example_name.Model.enums.ToolType.HOE;
import static io.github.some_example_name.Model.enums.ToolType.PICKAXE;

public class Tool {
    private final ToolType type;
    private final ToolMaterial material;
    private final int baseEnergyCost;
    private boolean equipped;

    public Tool(ToolType type, ToolMaterial material) {
        this.type = type;
        this.material = material;
        this.baseEnergyCost = calculateBaseEnergyCost();
        this.equipped = false;
    }

    private int calculateBaseEnergyCost() {
        return switch (type) {
            case HOE -> 5;
            case PICKAXE -> 5;
            case AXE -> 5;
            case WATERING_CAN -> 5;
            case FISHING_ROD -> 8;
            case SCYTHE -> 2;
            case MILK_PAIL -> 4;
            case SHEARS -> 4;
        };
    }

    public int getEffectiveEnergyCost(int skillLevel) {
        int materialReduction = material.ordinal(); // BASIC=0, COPPER=1, etc.
        int totalReduction = materialReduction + skillLevel;
        return Math.max(1, baseEnergyCost - totalReduction);
    }

    // Getters
    public ToolType getType() { return type; }
    public ToolMaterial getMaterial() { return material; }
    public boolean isEquipped() { return equipped; }
    public void setEquipped(boolean equipped) { this.equipped = equipped; }
}



