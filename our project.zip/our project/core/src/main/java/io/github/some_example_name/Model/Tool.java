package io.github.some_example_name.Model;

import io.github.some_example_name.Model.enums.ToolType;


import io.github.some_example_name.Model.enums.ToolMaterial;

// 2 - نمایش ابزار فعلی
// 5 تا 12 - ابزارهای مختلف و مصرف انرژی آن‌ها بسته به نوع ابزار
public class Tool {
    private final ToolType type;
    private final ToolMaterial material;
    private final int baseEnergyCost;
    private boolean equipped;

    public Tool(ToolType type, ToolMaterial material) {
        this.type = type;
        this.material = material;
        this.baseEnergyCost = calculateBaseEnergyCost();
        this.equipped = false;
    }

    private int calculateBaseEnergyCost() {
        // مشخص کردن مقدار انرژی برای ابزارها (مصرف انرژی)

        // Using traditional switch statement instead of switch expression
        switch (type) {
            case HOE:
                return 5;
            case PICKAXE:
                return 5;
            case AXE:
                return 5;
            case WATERING_CAN:
                return 5;
            case FISHING_ROD:
                return 8;
            case SCYTHE:
                return 2;
            case MILK_PAIL:
                return 4;
            case SHEARS:
                return 4;
            default:
                return 0;
        }
    }

    public int getEffectiveEnergyCost(int skillLevel) {
        // محاسبه هزینه انرژی با توجه به سطح مهارت و جنس ابزار

        int materialReduction = material.ordinal(); // BASIC=0, COPPER=1, etc.
        int totalReduction = materialReduction + skillLevel;
        return Math.max(1, baseEnergyCost - totalReduction);
    }

    // Getters
    public ToolType getType() {
        return type;
    }

    public ToolMaterial getMaterial() {
        return material;
    }

    public boolean isEquipped() {
        return equipped;
    }

    public void setEquipped(boolean equipped) {
        this.equipped = equipped;
    }
}
