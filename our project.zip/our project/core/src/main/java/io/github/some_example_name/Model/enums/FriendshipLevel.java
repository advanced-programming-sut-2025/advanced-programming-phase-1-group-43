package io.github.some_example_name.Model.enums;

// ✅ [1 - وجود سطوح مختلف دوستی]

public enum FriendshipLevel {

    STRANGER(0, 0, 100),
    ACQUAINTANCE(1, 100, 300),
    FRIEND(2, 300, 600),
    CLOSE_FRIEND(3, 600, 1000),
    MARRIED(4, 1000, Integer.MAX_VALUE);

    private final int level;
    private final int minXp;
    private final int nextLevelXp;

    FriendshipLevel(int level, int minXp, int nextLevelXp) {
        this.level = level;
        this.minXp = minXp;
        this.nextLevelXp = nextLevelXp;
    }

    public static FriendshipLevel fromXp(int xp) {
        for (FriendshipLevel level : values()) {
            if (xp >= level.minXp && xp < level.nextLevelXp) {
                return level;
            }
        }
        return STRANGER;
    }

    // Getters
    public int getLevel() { return level; }
    public int getMinXp() { return minXp; }
    public int getNextLevelXp() { return nextLevelXp; }
}
