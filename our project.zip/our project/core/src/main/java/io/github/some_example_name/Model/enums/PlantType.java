package io.github.some_example_name.Model.enums;

public enum PlantType {
    CROP,
    TREE,
    FLOWER;
}
