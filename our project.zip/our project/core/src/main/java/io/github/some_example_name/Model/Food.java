package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.BuffType;
import io.github.some_example_name.Model.enums.FoodType;
public class Food {
    private final String id;
    private final String name;
    private final FoodType type;
    private final int energyRestore;
    private final BuffType buffType;
    private final int buffDuration; // in minutes

    public Food(String id, String name, FoodType type,
                int energyRestore, BuffType buffType,
                int buffDuration) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.energyRestore = energyRestore;
        this.buffType = buffType;
        this.buffDuration = buffDuration;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public FoodType getType() { return type; }
    public int getEnergyRestore() { return energyRestore; }
    public BuffType getBuffType() { return buffType; }
    public int getBuffDuration() { return buffDuration; }
}
