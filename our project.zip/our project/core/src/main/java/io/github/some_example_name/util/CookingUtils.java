package io.github.some_example_name.util;

import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.BuffType;
import io.github.some_example_name.Model.enums.FoodType;
import io.github.some_example_name.Model.enums.SkillType;
import io.github.some_example_name.Model.Skill;

public class CookingUtils {
    public static boolean canLearnRecipe(Recipe recipe, Player player) {
        int cookingLevel = player.getSkills().getLevel(SkillType.COOKING);
        return cookingLevel >= recipe.getRequiredSkillLevel();
    }

    public static Food createFoodFromRecipe(Recipe recipe) {
        // Determine food properties based on recipe
        FoodType type = determineFoodType(recipe);
        int energyRestore = calculateEnergyRestore(recipe);
        BuffType buffType = determineBuffType(recipe);
        int buffDuration = calculateBuffDuration(recipe);

        return new Food(
            "food_" + recipe.getId(),
            "Cooked " + recipe.getName(),
            type,
            energyRestore,
            buffType,
            buffDuration
        );
    }

    private static FoodType determineFoodType(Recipe recipe) {
        // Logic to determine food type based on ingredients
        return FoodType.MEAL; // Simplified
    }

    private static int calculateEnergyRestore(Recipe recipe) {
        // Base energy + bonus based on cooking level
        return 10 + (recipe.getRequiredSkillLevel() * 5);
    }

    private static BuffType determineBuffType(Recipe recipe) {
        // Logic to determine buff based on ingredients
        return BuffType.ENERGY_BOOST; // Simplified
    }

    private static int calculateBuffDuration(Recipe recipe) {
        // Base duration + bonus based on cooking level
        return 30 + (recipe.getRequiredSkillLevel() * 10);
    }
}
