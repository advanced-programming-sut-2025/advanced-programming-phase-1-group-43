package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.CookingError;

public class CookingResult {
    private final boolean success;
    private final CookingError error;
    private final Food food;

    public CookingResult(Food food) {
        this.success = true;
        this.error = null;
        this.food = food;
    }

    public CookingResult(CookingError error) {
        this.success = false;
        this.error = error;
        this.food = null;
    }

    // Getters and error message
    public boolean isSuccess() { return success; }
    public Food getFood() { return food; }
    public String getErrorMessage() { return error != null ? error.getMessage() : ""; }
}
