package io.github.some_example_name.Model;


//import io.github.some_example_name.Model.enums.SkillType;
import java.util.*;
import java.util.Map;

import io.github.some_example_name.Model.Position;
import io.github.some_example_name.Model.enums.FoodType;
import io.github.some_example_name.Model.enums.SkillType;
import io.github.some_example_name.Model.enums.ToolMaterial;
import io.github.some_example_name.Model.enums.ToolType;

import io.github.some_example_name.Model.enums.ItemType;
import io.github.some_example_name.Model.enums.SkillType;
import java.util.EnumMap;
import java.util.Map;


/**
 * کلاس Player که اطلاعات اصلی بازیکن را نگهداری می‌کند
 */



/**
 * Player class that maintains the player's main information
 */
public class Player {
    private String username;
    private Energy energy;
    private Position position;
    private Map<SkillType, Skill> skills;
    private Map<ToolType, Tool> tools;
    private Tool equippedTool;
    private Backpack backpack;
    private CraftingStation craftingStation;
    private Inventory inventory;
    private Refrigerator refrigerator;
    private Map<FoodType, Recipe> recipes;
    private Food activeBuff;
    private boolean isInHome = false;
    private final List<Recipe> knownRecipes;
    private final List<Buff> activeBuffs;
    private final List<String> notifications;

    public Player(String username) {
        this.username = username;
        this.energy = new Energy();

        this.position = new Position(0, 0);
        this.skills = new EnumMap<>(SkillType.class);
        this.tools = new EnumMap<>(ToolType.class);
        this.backpack = new Backpack(12);
        this.craftingStation = new CraftingStation();
        this.inventory = new Inventory(12);
        this.refrigerator = new Refrigerator();
        this.recipes = new HashMap<>();
        // ... سایر مقداردهی‌های اولیه ...
        this.knownRecipes = new ArrayList<>();
        this.skills = new EnumMap<>(SkillType.class);
        this.notifications = new ArrayList<>();

        initializeSkills();
        initializeBasicRecipes();
        initializeBasicTools();
        initializeSkills();
    }

    private void initializeSkills() {
        for (SkillType type : SkillType.values()) {
            skills.put(type, new Skill(type));
        }
    }
    public Player() {
        // ... existing initialization ...
        this.activeBuffs = new ArrayList<>();
    }

    // Add this method to Player class
    public List<Buff> getActiveBuffs() {
        return activeBuffs;
    }
    /**
     * Returns the player's skills map
     * @return Map of SkillType to Skill
     */
    public Map<SkillType, Skill> getSkills() {
        return skills;
    }
    /**
     * Gets a specific skill by type
     * @param type The skill type to get
     * @return The Skill object
     */
    public Skill getSkill(SkillType type) {
        return skills.get(type);
    }
    public void addNotification(String message) {
        notifications.add(message);
    }

    public List<String> getNotifications() {
        return new ArrayList<>(notifications);
    }

    public void clearNotifications() {
        notifications.clear();
    }
    /**
     * Gets the level of a specific skill
     * @param type The skill type to check
     * @return The current level of the skill
     */
    public int getSkillLevel(SkillType type) {
        return skills.get(type).getLevel();
    }
    private void initializeBasicRecipes() {
        recipes.put(FoodType.BREAD, new Recipe(
            FoodType.BREAD,
            Map.of(ItemType.WHEAT, 1),
            true, 0
        ));
    }

    private void initializeBasicRecipes() {
        // اضافه کردن دستورالعمل‌های اولیه
        knownRecipes.add(new Recipe("basic_meal", "Basic Meal",
            Map.of("Bread", 1, "Cheese", 1), 0));
    }

    // متدهای جدید
    public List<Recipe> getKnownRecipes() {
        return new ArrayList<>(knownRecipes); // Return a copy for encapsulation
    }

    public String getId() {
        // اگر Player کلاس ID دارد، آن را برگردانید
        // اگر نه، می‌توانید از username به عنوان ID استفاده کنید
        return this.username; // فرض می‌کنیم فیلد username وجود دارد
    }

    private void initializeBasicTools() {
        tools.put(ToolType.HOE, new Tool(ToolType.HOE, ToolMaterial.BASIC));
        tools.put(ToolType.PICKAXE, new Tool(ToolType.PICKAXE, ToolMaterial.BASIC));
        tools.put(ToolType.AXE, new Tool(ToolType.AXE, ToolMaterial.BASIC));
        tools.put(ToolType.WATERING_CAN, new Tool(ToolType.WATERING_CAN, ToolMaterial.BASIC));
        tools.put(ToolType.SCYTHE, new Tool(ToolType.SCYTHE, ToolMaterial.BASIC));
    }

    private void initializeSkills() {
        for (SkillType type : SkillType.values()) {
            skills.put(type, new Skill(type));
        }
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public Energy getEnergy() {
        return energy;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(int x, int y) {
        this.position.setX(x);
        this.position.setY(y);
    }

    public Optional<Tool> getEquippedTool() {
        return Optional.ofNullable(equippedTool);
    }

    public void setEquippedTool(Tool tool) {
        this.equippedTool = tool;
    }

    public Map<ToolType, Tool> getTools() {
        return tools;
    }



    public Backpack getBackpack() {
        return backpack;
    }

    public CraftingStation getCraftingStation() {
        return craftingStation;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Refrigerator getRefrigerator() {
        return refrigerator;
    }

    public Map<FoodType, Recipe> getRecipes() {
        return recipes;
    }

    public Food getActiveBuff() {
        return activeBuff;
    }

    public void setActiveBuff(Food activeBuff) {
        this.activeBuff = activeBuff;
    }

    public boolean isInHome() {
        return isInHome;
    }

    public void setInHome(boolean inHome) {
        isInHome = inHome;
    }
}
