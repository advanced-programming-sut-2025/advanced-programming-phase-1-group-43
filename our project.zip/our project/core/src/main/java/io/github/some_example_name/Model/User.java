package io.github.some_example_name.Model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;
import io.github.some_example_name.Model.enums.SkillType;

public class User implements Serializable {
    private io.github.some_example_name.Model.Farm farm = new io.github.some_example_name.Model.Farm(); // each user has a farm
    private Energy energy;
    private Map<Skill.SkillType, Skill> skills;
    private transient Farm farm;
    private static final long serialVersionUID = 1L;
    private String username;
    private String nickname;
    private String passwordHash;
    private String email;
    private String gender;
    private String securityQuestion;
    private String securityAnswerHash;

    // Game stats:
    private int highestGold;
    private int gamesPlayed;

    public User(String username,
                String nickname,
                String passwordHash,
                String email,
                String gender,
                String securityQuestion,
                String securityAnswerHash) {
        this.username = username;
        this.nickname = nickname;
        this.passwordHash = passwordHash;
        this.email = email;
        this.gender = gender;
        this.securityQuestion = securityQuestion;
        this.securityAnswerHash = securityAnswerHash;
        this.highestGold = 0;
        this.gamesPlayed = 0;
        this.energy = new Energy(this);
        this.skills = new HashMap<>();
        initializeSkills();
        this.farm = new Farm();
    }


    public User() {
        this.gender = null;
    }

    // Getters & setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getGender() { return gender; }

    public String getSecurityQuestion() { return securityQuestion; }
    public void setSecurityQuestion(String securityQuestion) { this.securityQuestion = securityQuestion; }

    public String getSecurityAnswerHash() { return securityAnswerHash; }
    public void setSecurityAnswerHash(String securityAnswerHash) { this.securityAnswerHash = securityAnswerHash; }

    public int getHighestGold() { return highestGold; }
    public int getGamesPlayed() { return gamesPlayed; }

    public io.github.some_example_name.Model.Farm getFarm() {
        return farm;
    }

    public void recordGame(int goldEarned) {
        gamesPlayed++;
        if (goldEarned > highestGold) {
            highestGold = goldEarned;
        }
    }

    public void resetDaily() {
        // placeholder for daily resets (e.g. energy, daily quests)
    }
    private void initializeSkills() {
        for (Skill.SkillType type : Skill.SkillType.values()) {
            skills.put(type, new Skill(type, this));
        }
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return Objects.equals(username, user.username);
    }
    public Energy getEnergy() { return energy; }

    public Skill getSkill(Skill.SkillType type) {
        return skills.get(type);
    }
    public String showSkills() {
        StringBuilder sb = new StringBuilder();
        for (Skill skill : skills.values()) {
            sb.append(skill.show()).append("\n");
        }
        return sb.toString();
    }
    @Override
    public int hashCode() {
        return Objects.hash(username);
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", nickname='" + nickname + '\'' +
                ", email='" + email + '\'' +
                ", gender='" + gender + '\'' +
                ", highestGold=" + highestGold +
                ", gamesPlayed=" + gamesPlayed +
                '}';
    }
}
