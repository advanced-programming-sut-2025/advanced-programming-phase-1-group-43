package io.github.some_example_name.service;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.CraftingError;
import io.github.some_example_name.util.CraftingUtils;
import io.github.some_example_name.Model.Inventory;

import javax.swing.text.Position;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
public class CraftingService {
    private final CraftingStation craftingStation;
    private final Player player;
    private final EnergyService energyService;
    private final InventoryService inventoryService;
    private final SkillService skillService;

    public CraftingService(CraftingStation craftingStation, Player player,
                           EnergyService energyService,
                           InventoryService inventoryService,
                           SkillService skillService) {
        this.craftingStation = craftingStation;
        this.player = player;
        this.energyService = energyService;
        this.inventoryService = inventoryService;
        this.skillService = skillService;
    }

    public List<Recipe> getLearnableRecipes() {
        return craftingStation.getAvailableRecipes().stream()
            .filter(recipe -> !recipe.isLearned())
            .filter(recipe -> craftingStation.canLearnRecipe(recipe, player))
            .collect(Collectors.toList());
    }

    public List<Recipe> getCraftableRecipes() {
        return craftingStation.getAvailableRecipes().stream()
            .filter(Recipe::isLearned)
            .filter(recipe -> recipe.canCraft(player))
            .collect(Collectors.toList());
    }



    public boolean learnRecipe(String recipeId) {
        Optional<Recipe> recipeOpt = findRecipeById(recipeId);
        if (recipeOpt.isPresent() &&
            craftingStation.canLearnRecipe(recipeOpt.get(), player)) {
            craftingStation.learnRecipe(recipeOpt.get(), player);
            return true;
        }
        return false;
    }

    public boolean placeItem(String itemId, Position position) {
        if (!inventoryService.hasItem(player, itemId)) {
            return false;
        }

        // Check if position is valid for placement
        if (!CraftingUtils.isValidPlacementPosition(position)) {
            return false;
        }

        // Remove from inventory and place in world
        inventoryService.removeItem(player, itemId, 1);
        return WorldMap.placeItem(itemId, position);
        //WorldMap requires map details
    }

    private Optional<Recipe> findRecipeById(String recipeId) {
        return craftingStation.getAvailableRecipes().stream()
            .filter(r -> r.getId().equals(recipeId))
            .findFirst();
    }
    public CraftingResult craftItem(String recipeId) {
        // 1. Check if player is at crafting station
        if (!craftingStation.isInHome()) {
            return new CraftingResult(CraftingError.NOT_IN_HOME);
        }

        // 2. Find the recipe
        Optional<Recipe> recipeOpt = findRecipeById(recipeId);
        if (recipeOpt.isEmpty()) {
            return new CraftingResult(CraftingError.RECIPE_NOT_FOUND);
        }

        Recipe recipe = recipeOpt.get();

        // 3. Check if recipe is learned
        if (!recipe.isLearned()) {
            return new CraftingResult(CraftingError.RECIPE_NOT_LEARNED);
        }

        // 4. Check materials
        if (!inventoryService.hasItems(player, recipe.getRequiredMaterials())) {
            return new CraftingResult(CraftingError.INSUFFICIENT_MATERIALS);
        }

        // 5. Check energy
        if (!energyService.hasEnoughEnergy(player, 2)) {
            return new CraftingResult(CraftingError.INSUFFICIENT_ENERGY);
        }

        // 6. Check inventory space
        if (inventoryService.isFull(player)) {
            return new CraftingResult(CraftingError.INVENTORY_FULL);
        }

        try {
            // 7. Consume resources
            inventoryService.removeItems(player, recipe.getRequiredMaterials());
            energyService.consumeEnergy(player, 2);

            // 8. Create the item
            Item craftedItem = CraftingUtils.createItemFromRecipe(recipe);

            // 9. Add to inventory
            boolean added = inventoryService.addItem(player, craftedItem);
            if (!added) {
                // Rollback if adding failed
                inventoryService.addItems(player, recipe.getRequiredMaterials());
                energyService.restoreEnergy(player, 2);
                return new CraftingResult(CraftingError.INVENTORY_FULL);
            }

            return new CraftingResult(craftedItem);
        } catch (Exception e) {
            // Handle any unexpected errors
            return new CraftingResult(CraftingError.INVENTORY_FULL);
        }
    }
}
