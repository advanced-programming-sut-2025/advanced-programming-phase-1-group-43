package io.github.some_example_name.Exception;


public class GameException extends Exception {
    public GameException(String message) {
        super(message);
    }
}
