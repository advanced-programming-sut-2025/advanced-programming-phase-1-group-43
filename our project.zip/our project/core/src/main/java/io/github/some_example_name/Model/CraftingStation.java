package io.github.some_example_name.Model;

import io.github.some_example_name.Model.enums.ItemType;
import io.github.some_example_name.util.CraftingUtils;

import java.util.ArrayList;
import java.util.List;

public class CraftingStation {
    private final List<Recipe> availableRecipes;
    private boolean inHome;

    public CraftingStation() {
        this.availableRecipes = new ArrayList<>();
        this.inHome = false;
        initializeBasicRecipes();
    }

    private void initializeBasicRecipes() {
        availableRecipes.add(new Recipe("wood_fence", "Wood Fence", ItemType.FURNITURE,
            Map.of("Wood", 2), 0));
        //of requires map details
        availableRecipes.add(new Recipe("stone_path", "Stone Path", ItemType.DECORATION,
            Map.of("Stone", 1), 1));
        // Add more basic recipes
    }
// ✅ [5 - یادگیری دستور العمل] - اضافه شدن دستورالعمل جدید به لیست دستورالعمل‌ها

    public void learnRecipe(Recipe recipe, Player player) {
        if (canLearnRecipe(recipe, player)) {
            recipe.setLearned(true);
        }
    }
// ✅ [6 - قفل بودن دستور العمل] - باز نبودن تمام دستورالعمل‌ها از ابتدا

    public boolean canLearnRecipe(Recipe recipe, Player player) {
        return CraftingUtils.canLearnRecipe(recipe, player);
    }

    // Getters
    public List<Recipe> getAvailableRecipes() { return availableRecipes; }
    public boolean isInHome() { return inHome; }
    public void setInHome(boolean inHome) { this.inHome = inHome; }
}
