package io.github.some_example_name.Model;

public class Store extends Model.Building {
}
