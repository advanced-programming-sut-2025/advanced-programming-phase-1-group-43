package io.github.some_example_name.service;


import io.github.some_example_name.Model.Food;
import io.github.some_example_name.Model.enums.EatingError;

public class EatingResult {
    private final boolean success;
    private final EatingError error;
    private final Food food;

    public EatingResult(Food food) {
        this.success = true;
        this.error = null;
        this.food = food;
    }

    public EatingResult(EatingError error) {
        this.success = false;
        this.error = error;
        this.food = null;
    }

    // Getters
    public boolean isSuccess() { return success; }
    public Food getFood() { return food; }
    public String getErrorMessage() {
        return error != null ? error.getMessage() : "";
    }
}
