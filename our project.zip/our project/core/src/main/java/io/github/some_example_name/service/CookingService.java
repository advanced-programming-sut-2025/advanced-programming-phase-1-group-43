package io.github.some_example_name.service;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.BuffType;
import io.github.some_example_name.util.CookingUtils;
import io.github.some_example_name.Model.enums.CookingError;
import io.github.some_example_name.Model.enums.EatingError;
import io.github.some_example_name.Model.enums.LearningError;
import io.github.some_example_name.Model.Item;

import java.util.Optional;

public class CookingService {
    private final Player player;
    private final EnergyService energyService;
    private final InventoryService inventoryService;
    private final SkillService skillService;
    private final BuffService buffService;

    public CookingService(Player player, EnergyService energyService,
                          InventoryService inventoryService,
                          SkillService skillService,
                          BuffService buffService) {
        this.player = player;
        this.energyService = energyService;
        this.inventoryService = inventoryService;
        this.skillService = skillService;
        this.buffService = buffService;
    }

    public CookingResult prepareFood(String recipeId) {
        if (!player.isInHome()) {
            return new CookingResult(CookingError.NOT_IN_HOME);
        }

        Optional<Recipe> recipeOpt = findRecipeById(recipeId);
        if (recipeOpt.isEmpty()) {
            return new CookingResult(CookingError.RECIPE_NOT_FOUND);
        }

        Recipe recipe = recipeOpt.get();

        if (!recipe.isLearned()) {
            return new CookingResult(CookingError.RECIPE_NOT_LEARNED);
        }

        if (!hasRequiredIngredients(recipe)) {
            return new CookingResult(CookingError.INSUFFICIENT_INGREDIENTS);
        }

        if (!energyService.hasEnoughEnergy(player, 3)) {
            return new CookingResult(CookingError.INSUFFICIENT_ENERGY);
        }

        // Consume resources
        consumeIngredients(recipe);
        energyService.consumeEnergy(player, 3);

        // Create food item
        Food food = CookingUtils.createFoodFromRecipe(recipe);
        inventoryService.addItem(player, food);

        return new CookingResult(food);
    }

    public EatingResult eatFood(String foodId) {
        Optional<Food> foodOpt = inventoryService.getItem(player, foodId, Food.class);
        if (foodOpt.isEmpty()) {
            return new EatingResult(EatingError.FOOD_NOT_FOUND);
        }

        Food food = foodOpt.get();

        // Remove from inventory
        inventoryService.removeItem(player, foodId, 1);

        // Apply effects
        energyService.restoreEnergy(player, food.getEnergyRestore());
        buffService.applyBuff(player, food.getBuffType(), food.getBuffDuration());

        return new EatingResult(food);
    }

    public LearningResult learnRecipe(String recipeId) {
        Optional<Recipe> recipeOpt = findRecipeById(recipeId);
        if (recipeOpt.isEmpty()) {
            return new LearningResult(LearningError.RECIPE_NOT_FOUND);
        }

        Recipe recipe = recipeOpt.get();

        if (recipe.isLearned()) {
            return new LearningResult(LearningError.ALREADY_LEARNED);
        }

        if (!CookingUtils.canLearnRecipe(recipe, player)) {
            return new LearningResult(LearningError.INSUFFICIENT_SKILL);
        }

        recipe.setLearned(true);
        return new LearningResult(recipe);
    }

    // Helper methods
    private Optional<Recipe> findRecipeById(String recipeId) {
        return player.getKnownRecipes().stream()
            .filter(r -> r.getId().equals(recipeId))
            .findFirst();
    }

    private boolean hasRequiredIngredients(Recipe recipe) {
        // Check both inventory and refrigerator
        return recipe.getRequiredMaterials().entrySet().stream()
            .allMatch(entry ->
                inventoryService.hasItem(player, entry.getKey(), entry.getValue()) ||
                    player.getRefrigerator().hasItem(entry.getKey(), entry.getValue())
            );
    }

    private void consumeIngredients(Recipe recipe) {
        recipe.getRequiredMaterials().forEach((itemId, quantity) -> {
            // Try to take from inventory first
            if (!inventoryService.removeItem(player, itemId, quantity)) {
                // Then take from refrigerator
                player.getRefrigerator().removeItem(itemId, quantity);
            }
        });
    }
}
