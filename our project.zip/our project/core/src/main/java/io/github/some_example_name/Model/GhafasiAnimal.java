package io.github.some_example_name.Model;

public class GhafasiAnimal extends Model.Animal {
}
