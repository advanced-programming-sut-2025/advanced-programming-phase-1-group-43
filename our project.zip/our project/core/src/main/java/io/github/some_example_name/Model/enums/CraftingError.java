package io.github.some_example_name.Model.enums;

public enum CraftingError {
    NOT_IN_HOME,
    RECIPE_NOT_FOUND,
    RECIPE_NOT_LEARNED,
    INSUFFICIENT_MATERIALS,
    INSUFFICIENT_ENERGY,
    INVENTORY_FULL,
    INVALID_POSITION,
    INSUFFICIENT_SKILL
}
