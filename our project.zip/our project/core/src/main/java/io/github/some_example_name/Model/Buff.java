package io.github.some_example_name.Model;


import io.github.some_example_name.Model.enums.BuffType;

public class Buff {
    private final BuffType type;
    private int remainingDuration; // in minutes

    public Buff(BuffType type, int durationMinutes) {
        this.type = type;
        this.remainingDuration = durationMinutes;
    }

    public void reduceDuration(long minutes) {
        this.remainingDuration = Math.max(0, remainingDuration - (int)minutes);
    }

    // Getters
    public BuffType getType() { return type; }
    public int getRemainingDuration() { return remainingDuration; }
}
