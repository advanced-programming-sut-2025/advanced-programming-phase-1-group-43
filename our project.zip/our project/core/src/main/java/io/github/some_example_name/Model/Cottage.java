package io.github.some_example_name.Model;

public class Cottage {
    public int FirstX;
    public int FirstY;
    public int SecondX;
    public int SecondY;

    public Cottage(int firstX,int firstY,int secondX,int secondY) {
        FirstX = firstX;
        FirstY = firstY;
        SecondX = secondX;
        SecondY = secondY;
    }

}
