package io.github.some_example_name.Controller;
import io.github.some_example_name.Model.CraftingResult;
import io.github.some_example_name.Model.Recipe;
import io.github.some_example_name.service.CraftingService;
import io.github.some_example_name.Model.Position;
//import javax.swing.text.Position;
import java.util.List;

public class CraftingController {
    private static final String CRAFT_PREFIX = "craft ";
    private static final String LEARN_PREFIX = "learn ";
    private static final String PLACE_PREFIX = "place ";

    private final CraftingService craftingService;

    public CraftingController(CraftingService craftingService) {
        this.craftingService = craftingService;
    }

    public String handleCommand(String input) {
        if (input.startsWith(CRAFT_PREFIX)) {
            String recipeId = input.substring(CRAFT_PREFIX.length()).trim();
            return handleCraftCommand(recipeId);
        }
        else if (input.startsWith(LEARN_PREFIX)) {
            String recipeId = input.substring(LEARN_PREFIX.length()).trim();
            return handleLearnCommand(recipeId);
        }
        else if (input.startsWith(PLACE_PREFIX)) {
            String[] parts = input.substring(PLACE_PREFIX.length()).split(" ");
            if (parts.length == 2) {
                return handlePlaceCommand(parts[0], parts[1]);
            }
            return "Invalid place command format";
        }
        else if (input.equals("recipes")) {
            return showAvailableRecipes();
        }
        return "Unknown crafting command";
    }

    private String handleCraftCommand(String recipeId) {
        boolean success = craftingService.craftItem(recipeId).isSuccess();
        return success ? "Successfully crafted item" : "Failed to craft item";
    }

    private String handleLearnCommand(String recipeId) {
        boolean success = craftingService.learnRecipe(recipeId);
        return success ? "Learned new recipe" : "Failed to learn recipe";
    }

    private String handlePlaceCommand(String itemId, String positionStr) {
        try {
            Position position = Position.fromString(positionStr);
            boolean success = craftingService.placeItem(itemId, (javax.swing.text.Position) position);
            return success ? "Item placed successfully" : "Failed to place item";
        } catch (IllegalArgumentException e) {
            return "Invalid position format";
        }
    }

    private String showAvailableRecipes() {
        List<Recipe> craftable = craftingService.getCraftableRecipes();
        List<Recipe> learnable = craftingService.getLearnableRecipes();

        StringBuilder sb = new StringBuilder();
        sb.append("Craftable Recipes:\n");
        craftable.forEach(r -> sb.append("- ").append(r.getName()).append("\n"));

        sb.append("\nLearnable Recipes:\n");
        learnable.forEach(r -> sb.append("- ").append(r.getName())
            .append(" (Req. Level: ").append(r.getRequiredSkillLevel()).append(")\n"));

        return sb.toString();
    }
}
