package io.github.some_example_name.Controller;

import io.github.some_example_name.service.EnergyService;
import io.github.some_example_name.Model.Player;

/**
 * کنترلر مدیریت دستورات مربوط به انرژی
 */

import io.github.some_example_name.Model.User;
import io.github.some_example_name.Model.Energy;

public class EnergyController {
    private static final String CHEAT_PREFIX_SET = "energy set -v ";
    private static final String CHEAT_UNLIMITED = "energy unlimited";

    private final User user;

    public EnergyController(User user) {
        this.user = user;
    }

    public void handle(String cmd) {
        try {
            if (cmd.equals("energy show")) {
                System.out.println(user.getEnergy().show());
            }
            else if (cmd.startsWith(CHEAT_PREFIX_SET)) {
                int value = Integer.parseInt(cmd.substring(CHEAT_PREFIX_SET.length()).trim());
                user.getEnergy().setEnergy(value);
                System.out.println("Energy set to: " + value);
            }
            else if (cmd.equals(CHEAT_UNLIMITED)) {
                user.getEnergy().setUnlimited(true);
                System.out.println("Energy is now unlimited");
            }
            else {
                System.out.println("Invalid energy command");
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}
