package io.github.some_example_name.service.managers;

import io.github.some_example_name.Model.Position;

public class FarmManager {
    public boolean tillSoil(Position position, int direction) {
        // پیاده‌سازی منطق شخم زدن خاک
        return true;
    }

    public boolean waterCrops(Position position, int direction) {
        // پیاده‌سازی منطق آبیاری محصولات
        return true;
    }

    public boolean harvestCrops(Position position, int direction) {
        // پیاده‌سازی منطق برداشت محصولات
        return true;
    }
}
