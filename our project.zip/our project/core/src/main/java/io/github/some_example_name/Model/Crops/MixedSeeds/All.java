package io.github.some_example_name.Model.Crops.MixedSeeds;

public class All {
        public static class Cauliflower {
            public static final String SEASON = "Spring";
        }

        public static class Parsnip {
            public static final String SEASON = "Spring";
        }

        public static class Potato {
            public static final String SEASON = "Spring";
        }

        public static class BlueJazz {
            public static final String SEASON = "Spring";
        }

        public static class Tulip {
            public static final String SEASON = "Spring";
        }

        public static class Corn {
            public static final String SEASON = "Summer";
        }

        public static class HotPepper {
            public static final String SEASON = "Summer";
        }

        public static class Radish {
            public static final String SEASON = "Summer";
        }

        public static class Wheat {
            public static final String SEASON = "Summer";
        }

        public static class Poppy {
            public static final String SEASON = "Summer";
        }

        public static class Sunflower {
            public static final String SEASON = "Summer";
        }

        public static class SummerSpangle {
            public static final String SEASON = "Summer";
        }

        public static class Artichoke {
            public static final String SEASON = "Fall";
        }

        public static class Eggplant {
            public static final String SEASON = "Fall";
        }

        public static class Pumpkin {
            public static final String SEASON = "Fall";
        }

        public static class FairyRose {
            public static final String SEASON = "Fall";
        }

        public static class Powdermelon {
            public static final String SEASON = "Winter";
        }

}
