package io.github.some_example_name.Model;


import java.util.HashMap;
import java.util.Map;

public class Backpack {
    private final int capacity;
    private final Map<String, Integer> items;
    // 1 - تجهیز شدن به ابزار در صورت وجود در کوله پشتی
// 13 - کوله : نمایش اجزای کوله پشتی و بررسی ظرفیت
    public Backpack(int capacity) {
        this.capacity = capacity;
        this.items = new HashMap<>();
    }

    public boolean addItem(String itemId, int quantity) {
        // اضافه کردن آیتم به کوله پشتی با بررسی ظرفیت

        int currentQuantity = items.getOrDefault(itemId, 0);
        int newTotal = getTotalItems() + quantity;

        if (newTotal > capacity) {
            return false;
        }

        items.put(itemId, currentQuantity + quantity);
        return true;
    }

    public boolean removeItem(String itemId, int quantity) {
        // حذف آیتم از کوله پشتی

        if (!items.containsKey(itemId)) {
            return false;
        }

        int currentQuantity = items.get(itemId);
        if (currentQuantity < quantity) {
            return false;
        }

        if (currentQuantity == quantity) {
            items.remove(itemId);
        } else {
            items.put(itemId, currentQuantity - quantity);
        }

        return true;
    }

    public boolean hasItem(String itemId, int quantity) {
        // بررسی وجود آیتم مشخص با تعداد

        return items.getOrDefault(itemId, 0) >= quantity;
    }

    public int getItemCount(String itemId) {
        return items.getOrDefault(itemId, 0);
    }

    public int getTotalItems() {
        return items.values().stream().mapToInt(Integer::intValue).sum();
    }

    public boolean isFull() {
        return getTotalItems() >= capacity;
    }

    // Getters
    public int getCapacity() { return capacity; }
    public Map<String, Integer> getItems() { return items; }
}
