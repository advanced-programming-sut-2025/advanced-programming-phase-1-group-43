package io.github.some_example_name.Model;


import java.util.HashMap;
import java.util.Map;

public class Backpack {
    private final int capacity;
    private final Map<String, Integer> items;

    public Backpack(int capacity) {
        this.capacity = capacity;
        this.items = new HashMap<>();
    }

    public boolean addItem(String itemId, int quantity) {
        int currentQuantity = items.getOrDefault(itemId, 0);
        int newTotal = getTotalItems() + quantity;

        if (newTotal > capacity) {
            return false;
        }

        items.put(itemId, currentQuantity + quantity);
        return true;
    }

    public boolean removeItem(String itemId, int quantity) {
        if (!items.containsKey(itemId)) {
            return false;
        }

        int currentQuantity = items.get(itemId);
        if (currentQuantity < quantity) {
            return false;
        }

        if (currentQuantity == quantity) {
            items.remove(itemId);
        } else {
            items.put(itemId, currentQuantity - quantity);
        }

        return true;
    }

    public boolean hasItem(String itemId, int quantity) {
        return items.getOrDefault(itemId, 0) >= quantity;
    }

    public int getItemCount(String itemId) {
        return items.getOrDefault(itemId, 0);
    }

    public int getTotalItems() {
        return items.values().stream().mapToInt(Integer::intValue).sum();
    }

    public boolean isFull() {
        return getTotalItems() >= capacity;
    }

    // Getters
    public int getCapacity() { return capacity; }
    public Map<String, Integer> getItems() { return items; }
}
