package io.github.some_example_name.View.MenuViews;

public class MainMenuView {
    public void showHeader() { /* print "=== Register ===" */ }
    public String readUsername() { /* prompt and return */ return null; }
    public String readPassword() { return null; }
    public String readPasswordConfirm() { return null; }
    public String readEmail() { return null; }
    public String readSecurityQuestion() { return null; }
    public void showSuccess() { /* print success */ }
    public void showError(String msg) { /* print error */ }
}
