package io.github.some_example_name.Model;

public class StoneMining {
    public int FirstX;
    public int FirstY;
    public int SecondX;
    public int SecondY;

    public StoneMining(int firstX, int firstY, int secondX, int secondY) {
        FirstX = firstX;
        FirstY = firstY;
        SecondX = secondX;
        SecondY = secondY;
    }
}
