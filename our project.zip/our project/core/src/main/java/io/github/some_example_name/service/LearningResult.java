package io.github.some_example_name.service;


import io.github.some_example_name.Model.Recipe;
import io.github.some_example_name.Model.enums.LearningError;

public class LearningResult {
    private final boolean success;
    private final LearningError error;
    private final Recipe recipe;

    public LearningResult(Recipe recipe) {
        this.success = true;
        this.error = null;
        this.recipe = recipe;
    }

    public LearningResult(LearningError error) {
        this.success = false;
        this.error = error;
        this.recipe = null;
    }

    // Getters
    public boolean isSuccess() { return success; }
    public Recipe getRecipe() { return recipe; }
    public String getErrorMessage() {
        return error != null ? error.getMessage() : "";
    }
}
