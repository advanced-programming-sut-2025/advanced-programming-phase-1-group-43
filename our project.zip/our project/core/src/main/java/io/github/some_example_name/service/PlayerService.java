package io.github.some_example_name.service;

import io.github.some_example_name.Model.Player;

import javax.swing.text.Position;

public class PlayerService {
    // ... existing code ...

    public Position getPlayerPosition(String username) {
        Player player = getPlayer(username);
        return (Position) player.getPosition();
    }

    public void notifyPlayer(String username, String message) {
        Player player = getPlayer(username);
        player.addNotification(message);
    }

    // ... existing code ...
}
