package io.github.some_example_name.service.managers;


import io.github.some_example_name.Model.Position;

public class ForestryManager {
    public boolean chopTree(Position position, int direction) {
        // پیاده‌سازی منطق قطع درخت
        return true;
    }
}
