package io.github.some_example_name;

import io.github.some_example_name.Controller.MenuControllers.*;
import io.github.some_example_name.Controller.TimeController;
import io.github.some_example_name.Controller.WeatherController;
import Model.User;
import io.github.some_example_name.repository.GameRepository;
import io.github.some_example_name.repository.UserRepository;
import io.github.some_example_name.service.AuthService;
import io.github.some_example_name.service.GameService;
import io.github.some_example_name.service.TimeService;
import io.github.some_example_name.service.WeatherService;

import java.util.Optional;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            // 1. create repositories
            UserRepository userRepo = new UserRepository();
            Optional<String> saved = io.github.some_example_name.util.SessionManager.load();
            if (saved.isPresent()) {
                User u = userRepo.findByUsername(saved.get());
                if (u != null) {
                    userRepo.setCurrent(u);
                    System.out.println("Auto-login as " + u.getUsername());
                }
            }
            GameRepository gameRepo = new GameRepository(userRepo);

            // 2. create services
            AuthService authService = new AuthService(userRepo);
            WeatherService weatherService = new WeatherService();
            TimeService timeService = new TimeService(weatherService);
            GameService gameService = new GameService(gameRepo, userRepo, timeService);

            // 3. create controllers
            io.github.some_example_name.Controller.MenuControllers.RegistrationMenuController regCtrl = new io.github.some_example_name.Controller.MenuControllers.RegistrationMenuController(authService);
            io.github.some_example_name.Controller.MenuControllers.LoginMenuController loginCtrl = new io.github.some_example_name.Controller.MenuControllers.LoginMenuController(authService);
            io.github.some_example_name. Controller.MenuControllers.MainMenuController mainCtrl = new io.github.some_example_name.Controller.MenuControllers.MainMenuController(userRepo);
            io.github.some_example_name. Controller.MenuControllers.ProfileMenuController profCtrl = new io.github.some_example_name.Controller.MenuControllers.ProfileMenuController(authService);
            TimeController timeCtrl = new TimeController(timeService);
            WeatherController weatherCtrl = new WeatherController(weatherService);
            io.github.some_example_name.Controller.MenuControllers.GameMenuController gameCtrl = new io.github.some_example_name.Controller.MenuControllers.GameMenuController(gameService, timeCtrl, weatherCtrl);

            // 4. create and start menu router
            io.github.some_example_name.Controller.MenuControllers.MenuRouter router = new io.github.some_example_name.Controller.MenuControllers.MenuRouter(regCtrl, loginCtrl, mainCtrl, profCtrl, gameCtrl, scanner, userRepo);
            router.loop();

        } catch (Exception e) {
            System.err.println("Fatal error during startup: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
