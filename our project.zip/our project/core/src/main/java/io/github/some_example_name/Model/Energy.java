package io.github.some_example_name.Model;



/**
 * مدل انرژی که اطلاعات مربوط به انرژی بازیکن را نگهداری می‌کند
 */

import io.github.some_example_name.service.TimeService;

import java.io.Serializable;

public class Energy implements Serializable {
    private static final long serialVersionUID = 1L;

    private int currentEnergy;
    private int maxEnergy;
    private boolean unlimitedEnergy;
    private transient User user; // ارجاع به کاربر مرتبط

    public static final int DEFAULT_MAX_ENERGY = 200;
    public static final double FAINT_RECOVERY_PERCENT = 0.75;

    public Energy(User user) {
        this.user = user;
        this.maxEnergy = DEFAULT_MAX_ENERGY;
        this.currentEnergy = maxEnergy;
        this.unlimitedEnergy = false;
    }

    // متدهای اصلی
    public void consume(int amount) {
        if (unlimitedEnergy) return;

        currentEnergy = Math.max(0, currentEnergy - amount);
        if (currentEnergy <= 0) {
            faint();
        }
    }

    public void restore(int amount) {
        currentEnergy = Math.min(currentEnergy + amount, maxEnergy);
    }

    public void resetDaily() {
        if (!unlimitedEnergy) {
            currentEnergy = maxEnergy;
        }
    }


    private void faint() {
        currentEnergy = 0;
        // ارتباط با TimeService برای skip کردن روز
        TimeService timeService = user.getFarm().getTimeService();
        if (timeService != null) {
            timeService.cheatAdvanceDate(1); // رفتن به روز بعد
        }

        // بازیابی 75% انرژی
        currentEnergy = (int)(maxEnergy * FAINT_RECOVERY_PERCENT);

        // ذخیره موقعیت بازیکن قبل از غش کردن
        user.getFarm().saveFaintPosition();
    }

    // متدهای چیت
    public void setEnergy(int value) {
        if (value < 0) value = 0;
        currentEnergy = Math.min(value, maxEnergy);
    }

    public void setUnlimited(boolean unlimited) {
        this.unlimitedEnergy = unlimited;
        if (unlimited) {
            currentEnergy = Integer.MAX_VALUE;
        } else {
            currentEnergy = maxEnergy;
        }
    }

    // افزایش سقف انرژی
    public void increaseMaxEnergy(int amount) {
        maxEnergy += amount;
        currentEnergy += amount;
    }

    // نمایش وضعیت انرژی
    public String show() {
        if (unlimitedEnergy) {
            return "Energy: Unlimited";
        }
        return String.format("Energy: %d/%d", currentEnergy, maxEnergy);
    }

    // Getters
    public int getCurrentEnergy() { return currentEnergy; }
    public int getMaxEnergy() { return maxEnergy; }
    public boolean isUnlimited() { return unlimitedEnergy; }
}
