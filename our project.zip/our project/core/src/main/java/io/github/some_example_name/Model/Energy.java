package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.ActivityType;
import io.github.some_example_name.Model.Farm;


/**
 * مدل انرژی که اطلاعات مربوط به انرژی بازیکن را نگهداری می‌کند
 */

import io.github.some_example_name.service.TimeService;

import java.io.Serializable;


import io.github.some_example_name.Model.enums.ActivityType;
import java.io.Serializable;

/**
 * Energy model that manages player's energy system
 */
public class Energy implements Serializable {
    private static final long serialVersionUID = 1L;
    private int currentEnergy;
    private int maxEnergy;
    private boolean unlimitedEnergy;
    private transient User user;

    public static final int DEFAULT_MAX_ENERGY = 200;
    public static final double FAINT_RECOVERY_PERCENT = 0.75;

    public Energy(User user) {
        this.user = user;
        this.maxEnergy = DEFAULT_MAX_ENERGY;
        this.currentEnergy = maxEnergy;
        this.unlimitedEnergy = false;
    }

    // Core energy methods
    public boolean consume(int amount) {
        if (unlimitedEnergy) return false;

        currentEnergy = Math.max(0, currentEnergy - amount);
        if (currentEnergy <= 0) {
            faint();
            return true;
        }
        return false;
    }

    public void restore(int amount) {
        if (!unlimitedEnergy) {
            currentEnergy = Math.min(currentEnergy + amount, maxEnergy);
        }
    }

    public void resetDaily() {
        if (!unlimitedEnergy) {
            currentEnergy = maxEnergy;
        }
    }

    private void faint() {
        currentEnergy = 0;

        // Skip to next day
        if (user != null && user.getFarm() != null) {
            user.getFarm().advanceToNextDay();
            user.getFarm().savePlayerPosition(); // Save faint position
        }

        // Recover 75% energy
        currentEnergy = (int)(maxEnergy * FAINT_RECOVERY_PERCENT);
    }

    // Cheat methods
    public void setEnergy(int value) {
        if (!unlimitedEnergy) {
            currentEnergy = Math.max(0, Math.min(maxEnergy, value));
        }
    }

    public void setUnlimited(boolean unlimited) {
        this.unlimitedEnergy = unlimited;
        if (unlimited) {
            currentEnergy = Integer.MAX_VALUE;
        } else {
            currentEnergy = maxEnergy;
        }
    }

    // Energy management
    public void increaseMaxEnergy(int amount) {
        maxEnergy += amount;
        currentEnergy += amount;
    }

    // Status display
    public String show() {
        if (unlimitedEnergy) {
            return "Energy: Unlimited";
        }
        return String.format("Energy: %d/%d", currentEnergy, maxEnergy);
    }

    // Getters
    public int getCurrentEnergy() { return currentEnergy; }
    public int getMaxEnergy() { return maxEnergy; }
    public boolean isUnlimited() { return unlimitedEnergy; }

    // New methods to support TimeService integration
    public boolean decrease(int amount) {
        return consume(amount);
    }

    public void increase(int amount) {
        restore(amount);
    }

    public void setCurrent(int value) {
        setEnergy(value);
    }

    public void restoreForNewDay() {
        resetDaily();
    }

    public int getCurrent() {
        return getCurrentEnergy();
    }
}
