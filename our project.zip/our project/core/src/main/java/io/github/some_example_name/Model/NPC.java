package io.github.some_example_name.Model;

import java.util.List;

public class NPC {
    private String Name;
    private List<String> dialogueSet;
    private int friendShipLevel;
    private Tile location;
    private List<Model.Gift> gifts;

    public String talk() {
        return null;
    }

    public void mission() {

    }

    public void updateFriendship(int amount) {

    }
}
