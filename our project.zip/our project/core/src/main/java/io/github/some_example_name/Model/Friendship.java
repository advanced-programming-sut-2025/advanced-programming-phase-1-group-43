package io.github.some_example_name.Model;


import io.github.some_example_name.Model.enums.FriendshipLevel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
// ✅ [1 - وجود سطوح مختلف دوستی]
// ✅ [2 - سیستم xp برای بالا بردن سطح دوستی]
// ✅ [3 - قابلیت نمایش سطوح دوستی با سایر بازیکنان]
public class Friendship {
    private final String player1;
    private final String player2;
    private int xp;
    private final List<Interaction> interactions;
    private final List<Gift> gifts;
    private final List<ChatMessage> chatHistory;

    public Friendship(String player1, String player2) {
        this.player1 = player1;
        this.player2 = player2;
        this.xp = 0;
        this.interactions = new ArrayList<>();
        this.gifts = new ArrayList<>();
        this.chatHistory = new ArrayList<>();
    }
    public FriendshipLevel getLevel() {
        return FriendshipLevel.fromXp(xp);
    }


    public boolean isLevelFull(FriendshipLevel level) {
        return this.xp >= level.getNextLevelXp();
    }
    public void addXp(int amount) {
        this.xp = Math.max(0, this.xp + amount);
    }

    public FriendshipLevel getCurrentLevel() {
        return FriendshipLevel.fromXp(xp);
    }

    public boolean canLevelUp() {
        return xp >= getCurrentLevel().getNextLevelXp();
    }
    public void upgradeTo(FriendshipLevel newLevel) {
        if (getCurrentLevel().ordinal() < newLevel.ordinal()) {
            this.xp = newLevel.getMinXp();
        }
    }
    public String getPlayer1() {
        return player1;
    }

    public String getPlayer2() {
        return player2;
    }


    // Getters
    public int getXp() { return xp; }
    public List<Interaction> getInteractions() { return interactions; }
    public List<Gift> getGifts() { return gifts; }
    public List<ChatMessage> getChatHistory() { return chatHistory; }
}
