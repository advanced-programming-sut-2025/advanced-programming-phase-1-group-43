package io.github.some_example_name.Model.enums;


public enum BuffType {
    ENERGY_BOOST("Energy Boost"),
    SKILL_BOOST("Skill Boost"),
    HEALTH_REGEN("Health Regen"),
    LUCK_BOOST("Luck Boost");

    private final String displayName;

    BuffType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
