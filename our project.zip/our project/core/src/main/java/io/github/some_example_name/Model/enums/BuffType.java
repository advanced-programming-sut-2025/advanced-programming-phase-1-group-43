package io.github.some_example_name.Model.enums;

public enum BuffType {
    ENERGY_BOOST,
    SKILL_BOOST,
    HEALTH_REGEN,
    LUCK_BOOST
}
