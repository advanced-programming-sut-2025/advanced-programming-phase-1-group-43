package io.github.some_example_name.View;

public class WeatherView {
}
