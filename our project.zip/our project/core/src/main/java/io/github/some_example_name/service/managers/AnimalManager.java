package io.github.some_example_name.service.managers;


import io.github.some_example_name.Model.Position;

public class AnimalManager {
    public boolean milkAnimal(Position position, int direction) {
        // پیاده‌سازی منطق دوشیدن شیر
        return true;
    }

    public boolean shearAnimal(Position position, int direction) {
        // پیاده‌سازی منطق چیدن پشم
        return true;
    }
}
