package io.github.some_example_name.Model.enums;


public enum CookingError {
    NOT_IN_HOME("You must be at home to cook"),
    RECIPE_NOT_FOUND("Recipe not found"),
    RECIPE_NOT_LEARNED("You haven't learned this recipe yet"),
    INSUFFICIENT_INGREDIENTS("Not enough ingredients"),
    INSUFFICIENT_ENERGY("Not enough energy to cook"),
    INVENTORY_FULL("Inventory is full"),
    REFRIGERATOR_FULL("Refrigerator is full"),
    INSUFFICIENT_SKILL("Your cooking skill level is too low"),
    INVALID_ITEM("Item cannot be used for cooking"),
    FOOD_NOT_FOUND("Food item not found");

    private final String message;

    CookingError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public static CookingError fromString(String text) {
        for (CookingError error : CookingError.values()) {
            if (error.name().equalsIgnoreCase(text)) {
                return error;
            }
        }
        return null;
    }
}
