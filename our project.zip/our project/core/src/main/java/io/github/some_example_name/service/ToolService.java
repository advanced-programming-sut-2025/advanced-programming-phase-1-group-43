package io.github.some_example_name.service;
import io.github.some_example_name.Model.Player;
import io.github.some_example_name.Model.Skill;
import io.github.some_example_name.Model.Tool;
import io.github.some_example_name.Model.enums.ToolType;

import javax.swing.text.Position;
import java.util.List;
import java.util.Optional;
import io.github.some_example_name.service.managers.*;

public class ToolService {
    private final Player player;
    private final EnergyService energyService;
    private final SkillService skillService;
    private final FarmManager farmManager;
    private final MiningManager miningManager;
    private final ForestryManager forestryManager;
    private final FishingManager fishingManager;
    private final AnimalManager animalManager;

    public ToolService(Player player, EnergyService energyService,
                       SkillService skillService, FarmManager farmManager,
                       MiningManager miningManager, ForestryManager forestryManager,
                       FishingManager fishingManager, AnimalManager animalManager) {
        this.player = player;
        this.energyService = energyService;
        this.skillService = skillService;
        this.farmManager = farmManager;
        this.miningManager = miningManager;
        this.forestryManager = forestryManager;
        this.fishingManager = fishingManager;
        this.animalManager = animalManager;
    }

    public boolean equipTool(String toolName) {
        Optional<Tool> tool = findToolByName(toolName);
        if (tool.isPresent()) {
            player.getEquippedTool().ifPresent(t -> t.setEquipped(false));
            tool.get().setEquipped(true);
            player.setEquippedTool(tool.get());
            return true;
        }
        return false;
    }

    public Optional<Tool> findToolByName(String toolName) {
        List<Tool> tools = (List<Tool>) player.getTools();
        for (Tool tool : tools) {
            if (tool.getType().name().equalsIgnoreCase(toolName)) {
                return Optional.of(tool);
            }
        }
        return Optional.empty();
    }

    public boolean useTool(int direction) {
        Optional<Tool> equippedTool = player.getEquippedTool();
        if (!equippedTool.isPresent()) {
            return false;
        }

        Tool tool = equippedTool.get();
        Skill.SkillType relatedSkill = getRelatedSkillType(tool.getType());
        int skillLevel = relatedSkill != null ?
            skillService.getSkillLevel(player, relatedSkill) : 0;

        int energyCost = tool.getEffectiveEnergyCost(skillLevel);

        if (!energyService.hasEnoughEnergy(player, energyCost)) {
            return false;
        }

        boolean actionSuccess = performToolAction(tool, direction);
        if (actionSuccess) {
            energyService.consumeEnergy(player, energyCost);
            if (relatedSkill != null) {
                skillService.addExperience(player, relatedSkill, getXpForToolUse(tool.getType()));
            }
            return true;
        }
        return false;
    }

    private boolean performToolAction(Tool tool, int direction) {
        Position position = (Position) player.getPosition();
        switch (tool.getType()) {
            case HOE:
                return farmManager.tillSoil((io.github.some_example_name.Model.Position) position, direction);
            case PICKAXE:
                return miningManager.breakRock((io.github.some_example_name.Model.Position) position, direction);
            case AXE:
                return forestryManager.chopTree((io.github.some_example_name.Model.Position) position, direction);
            case WATERING_CAN:
                return farmManager.waterCrops((io.github.some_example_name.Model.Position) position, direction);
            case FISHING_ROD:
                return fishingManager.catchFish(player);
            case SCYTHE:
                return farmManager.harvestCrops((io.github.some_example_name.Model.Position) position, direction);
            case MILK_PAIL:
                return animalManager.milkAnimal((io.github.some_example_name.Model.Position) position, direction);
            case SHEARS:
                return animalManager.shearAnimal((io.github.some_example_name.Model.Position) position, direction);
            default:
                return false;
        }
    }

    private Skill.SkillType getRelatedSkillType(ToolType toolType) {
        switch (toolType) {
            case HOE:
            case WATERING_CAN:
                return Skill.SkillType.FARMING;
            case PICKAXE:
                return Skill.SkillType.MINING;
            case AXE:
                return Skill.SkillType.FORAGING;
            case FISHING_ROD:
                return Skill.SkillType.FISHING;
            default:
                return null;
        }
    }

    private int getXpForToolUse(ToolType toolType) {
        switch (toolType) {
            case HOE:
            case WATERING_CAN:
            case FISHING_ROD:
                return 5;
            case PICKAXE:
            case AXE:
                return 10;
            default:
                return 0;
        }
    }
}
