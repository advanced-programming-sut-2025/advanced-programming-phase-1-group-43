package io.github.some_example_name.service;
import io.github.some_example_name.Model.Player;
import io.github.some_example_name.Model.Skill;
import io.github.some_example_name.Model.Tool;
import io.github.some_example_name.Model.enums.ToolMaterial;
import io.github.some_example_name.Model.enums.ToolType;

import javax.swing.text.Position;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
public class ToolService {
    private final Player player;
    private final EnergyService energyService;
    private final SkillService skillService;

    public ToolService(Player player, EnergyService energyService, SkillService skillService) {
        this.player = player;
        this.energyService = energyService;
        this.skillService = skillService;
    }

    public boolean equipTool(String toolName) {
        Optional<Tool> tool = findToolByName(toolName);
        if (tool.isPresent()) {
            player.getEquippedTool().ifPresent(t -> t.setEquipped(false));
            tool.get().setEquipped(true);
            player.setEquippedTool(tool.get());
            return true;
        }
        return false;
    }

    public Optional<Tool> findToolByName(String toolName) {
        return player.getTools().stream()
            .filter(t -> t.getType().name().equalsIgnoreCase(toolName))
            .findFirst();
    }

    public boolean useTool(int direction) {
        return player.getEquippedTool()
            .map(tool -> {
                Skill.SkillType relatedSkill = getRelatedSkillType(tool.getType());
                int skillLevel = relatedSkill != null ?
                    skillService.getSkillLevel(player, relatedSkill) : 0;

                int energyCost = tool.getEffectiveEnergyCost(skillLevel);

                if (energyService.hasEnoughEnergy(player, energyCost)) {
                    boolean actionSuccess = performToolAction(tool, direction);
                    if (actionSuccess) {
                        energyService.consumeEnergy(player, energyCost);
                        if (relatedSkill != null) {
                            skillService.addExperience(player, relatedSkill, getXpForToolUse(tool.getType()));
                        }
                        return true;
                    }
                }
                return false;
            })
            .orElse(false);
    }

    private boolean performToolAction(Tool tool, int direction) {
        Position position = player.getPosition();
        return switch (tool.getType()) {
            case HOE -> FarmManager.tillSoil(position, direction);
            case PICKAXE -> MiningManager.breakRock(position, direction);
            case AXE -> ForestryManager.chopTree(position, direction);
            case WATERING_CAN -> FarmManager.waterCrops(position, direction);
            case FISHING_ROD -> FishingManager.catchFish(player);
            case SCYTHE -> FarmManager.harvestCrops(position, direction);
            case MILK_PAIL -> AnimalManager.milkAnimal(position, direction);
            case SHEARS -> AnimalManager.shearAnimal(position, direction);
        };
    }

    private Skill.SkillType getRelatedSkillType(ToolType toolType) {
        return switch (toolType) {
            case HOE, WATERING_CAN -> Skill.SkillType.FARMING;
            case PICKAXE -> Skill.SkillType.MINING;
            case AXE -> Skill.SkillType.FORAGING;
            case FISHING_ROD -> Skill.SkillType.FISHING;
            default -> null;
        };
    }

    private int getXpForToolUse(ToolType toolType) {
        return switch (toolType) {
            case HOE, WATERING_CAN, FISHING_ROD -> 5;
            case PICKAXE, AXE -> 10;
            default -> 0;
        };
    }
}
