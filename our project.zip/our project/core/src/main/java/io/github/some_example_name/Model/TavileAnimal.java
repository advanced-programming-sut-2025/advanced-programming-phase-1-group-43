package io.github.some_example_name.Model;

public class TavileAnimal extends Model.Animal {
}
