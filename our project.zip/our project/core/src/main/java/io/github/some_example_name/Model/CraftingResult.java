package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.CraftingError;

public class CraftingResult {
    private final boolean success;
    private final CraftingError error;
    private final Item craftedItem;

    // Successful crafting
    public CraftingResult(Item craftedItem) {
        this.success = true;
        this.error = null;
        this.craftedItem = craftedItem;
    }

    // Failed crafting
    public CraftingResult(CraftingError error) {
        this.success = false;
        this.error = error;
        this.craftedItem = null;
    }

    // Getters
    public boolean isSuccess() { return success; }
    public CraftingError getError() { return error; }
    public Item getCraftedItem() { return craftedItem; }

    public String getErrorMessage() {
        if (success) return "Crafting successful";
        return switch (error) {
            case NOT_IN_HOME -> "You must be at your home crafting station";
            case RECIPE_NOT_FOUND -> "Recipe not found";
            case RECIPE_NOT_LEARNED -> "Recipe not learned yet";
            case INSUFFICIENT_MATERIALS -> "Not enough materials";
            case INSUFFICIENT_ENERGY -> "Not enough energy";
            case INVENTORY_FULL -> "Inventory is full";
            case INVALID_POSITION -> "Invalid placement position";
            case INSUFFICIENT_SKILL -> "Skill level too low";
        };
    }
}
