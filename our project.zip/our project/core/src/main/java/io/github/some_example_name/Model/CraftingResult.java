package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.CraftingError;

// ✅ [3 - استفاده از دستورالعمل] - ساخت موفقیت‌آمیز یک آیتم
// ✅ [4 - خطاها] - تمام خطاهای مربوطه در این کلاس هندل می‌شود
// ✅ [8 - خطاها] - قرار دادن موفق / برداشتن آیتم‌ها با کلنگ (Invalid Position)


public class CraftingResult {
    private final boolean success;
    private final CraftingError error;
    private final Item craftedItem;

    // Successful crafting
    public CraftingResult(Item craftedItem) {
        this.success = true;
        this.error = null;
        this.craftedItem = craftedItem;
    }

    // Failed crafting
    public CraftingResult(CraftingError error) {
        this.success = false;
        this.error = error;
        this.craftedItem = null;
    }

    // Getters
    public boolean isSuccess() { return success; }
    public CraftingError getError() { return error; }
    public Item getCraftedItem() { return craftedItem; }

    public String getErrorMessage() {
        if (success) return "Crafting successful";

        if (error == null) return "Unknown error";

        switch (error) {
            case NOT_IN_HOME:
                return "You must be at your home crafting station";
            case RECIPE_NOT_FOUND:
                return "Recipe not found";
            case RECIPE_NOT_LEARNED:
                return "Recipe not learned yet";
            case INSUFFICIENT_MATERIALS:
                return "Not enough materials";
            case INSUFFICIENT_ENERGY:
                return "Not enough energy";
            case INVENTORY_FULL:
                return "Inventory is full";
            case INVALID_POSITION:
                return "Invalid placement position";
            case INSUFFICIENT_SKILL:
                return "Skill level too low";
            default:
                return "Unknown error";
        }
    }
}
