package io.github.some_example_name.service.managers;



import io.github.some_example_name.Model.Player;

public class FishingManager {
    public boolean catchFish(Player player) {
        // پیاده‌سازی منطق صید ماهی
        return true;
    }
}
