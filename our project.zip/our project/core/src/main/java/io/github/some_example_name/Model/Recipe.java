package io.github.some_example_name.Model;
import io.github.some_example_name.Model.enums.ItemType;
import java.util.Map;
import io.github.some_example_name.Model.Inventory;
public class Recipe {
    private final String id;
    private final String name;
    private final ItemType resultType;
    private final Map<String, Integer> requiredMaterials;
    private int requiredSkillLevel;
    private boolean learned;
    public Recipe(String id, String name, ItemType resultType,
                  Map<String, Integer> requiredMaterials,
                  int requiredSkillLevel) {
        this.id = id;
        this.name = name;
        this.resultType = resultType;
        this.requiredMaterials = requiredMaterials;
        this.requiredSkillLevel = requiredSkillLevel;
        this.learned = false;

    }
    // Add getter and setter for requiredSkillLevel
    public int getRequiredSkillLevel() {
        return requiredSkillLevel;
    }

    public void setRequiredSkillLevel(int requiredSkillLevel) {
        this.requiredSkillLevel = requiredSkillLevel;
    }
    public boolean canCraft(Player player) {
        return player.getInventory().hasItems(requiredMaterials) &&
            player.getEnergy().getCurrent() >= 2;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public boolean isLearned() { return learned; }
    public void setLearned(boolean learned) { this.learned = learned; }
    public Map<String, Integer> getRequiredMaterials() { return requiredMaterials; }
    public ItemType getResultType() { return resultType; }
}
