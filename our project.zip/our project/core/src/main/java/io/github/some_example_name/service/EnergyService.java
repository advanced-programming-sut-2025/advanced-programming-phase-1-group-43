package io.github.some_example_name.service;

import io.github.some_example_name.Model.Energy;
import io.github.some_example_name.Model.Player;
import io.github.some_example_name.Model.enums.ActivityType;

/**
 * سرویس مدیریت انرژی بازیکن
 */
public class EnergyService {
    private final Player player;

    public EnergyService(Player player) {
        this.player = player;
    }

    /**
     * مصرف انرژی برای یک فعالیت خاص
     * @param activityType نوع فعالیت
     * @return true اگر بازیکن غش کرده باشد
     */
    public boolean consumeEnergyForActivity(ActivityType activityType) {
        return player.getEnergy().decrease(activityType.getEnergyCost());
    }

    /**
     * افزایش انرژی بازیکن (مثلاً با خوردن غذا)
     * @param amount مقدار انرژی که باید افزایش یابد
     */
    public void restoreEnergy(int amount) {
        player.getEnergy().increase(amount);
    }

    /**
     * تنظیم انرژی به مقدار مشخص
     * @param value مقدار جدید انرژی
     */
    public void setEnergy(int value) {
        player.getEnergy().setCurrent(value);
    }

    /**
     * فعال/غیرفعال کردن حالت انرژی نامحدود
     * @param unlimited اگر true باشد، انرژی نامحدود می‌شود
     */
    public void setUnlimitedEnergy(boolean unlimited) {
        player.getEnergy().setUnlimited(unlimited);
    }

    /**
     * بازگرداندن انرژی در شروع روز جدید
     */
    public void restoreEnergyForNewDay() {
        player.getEnergy().restoreForNewDay();
    }

    /**
     * بررسی آیا بازیکن انرژی کافی برای فعالیت دارد
     * @param activityType نوع فعالیت
     * @return true اگر انرژی کافی وجود دارد
     */
    public boolean hasEnoughEnergy(ActivityType activityType) {
        return player.getEnergy().isUnlimited() ||
               player.getEnergy().getCurrent() >= activityType.getEnergyCost();
    }
}
