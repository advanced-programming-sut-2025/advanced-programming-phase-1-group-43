package io.github.some_example_name.Model;
import java.util.Map;

import java.util.HashMap;


public class Inventory {
    private final Map<String, Item> items;
    private final Map<String, Integer> itemCounts;
    private final int capacity;

    public Inventory(int capacity) {
        this.items = new HashMap<>();
        this.itemCounts = new HashMap<>();
        this.capacity = capacity;

    }

    public int getItemCount(String itemId) {
        return itemCounts.getOrDefault(itemId, 0);
    }

    public Item getItem(String itemId) {
        return items.get(itemId);
    }

    public boolean addItem(String itemId, int quantity) {
        if (isFull()) return false;

        itemCounts.merge(itemId, quantity, Integer::sum);
        return true;
    }

    public void removeItem(String itemId, int quantity) {
        int current = itemCounts.getOrDefault(itemId, 0);
        if (current <= quantity) {
            itemCounts.remove(itemId);
            items.remove(itemId);
        } else {
            itemCounts.put(itemId, current - quantity);
        }
    }

    public boolean isFull() {
        return getTotalItems() >= capacity;
    }

    private int getTotalItems() {
        return itemCounts.values().stream().mapToInt(Integer::intValue).sum();
    }
}
