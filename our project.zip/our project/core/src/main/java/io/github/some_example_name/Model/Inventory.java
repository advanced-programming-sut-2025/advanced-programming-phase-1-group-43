package io.github.some_example_name.Model;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
public class Inventory {
    private final Map<String, Integer> items;
    private final int capacity;
    private int occupiedSlots;

    public Inventory(int capacity) {
        this.items = new HashMap<>();
        this.capacity = capacity;
        this.occupiedSlots = 0;
    }

    // Add item to inventory (stackable items)
    public boolean addItem(String itemId, int quantity) {
        if (quantity <= 0) {
            return false;
        }

        // Check if we're adding a new item or stacking
        boolean isNewItem = !items.containsKey(itemId);
        int addedSlots = isNewItem ? 1 : 0;

        if (occupiedSlots + addedSlots > capacity) {
            return false;
        }

        items.merge(itemId, quantity, Integer::sum);
        occupiedSlots += addedSlots;
        return true;
    }

    // Remove item from inventory
    public boolean removeItem(String itemId, int quantity) {
        if (quantity <= 0 || !items.containsKey(itemId)) {
            return false;
        }

        int currentQuantity = items.get(itemId);
        if (currentQuantity < quantity) {
            return false;
        }

        if (currentQuantity == quantity) {
            items.remove(itemId);
            occupiedSlots--;
        } else {
            items.put(itemId, currentQuantity - quantity);
        }

        return true;
    }

    // Check if item exists in sufficient quantity
    public boolean hasItem(String itemId, int quantity) {
        return items.getOrDefault(itemId, 0) >= quantity;
    }

    // Get count of specific item
    public int getItemCount(String itemId) {
        return items.getOrDefault(itemId, 0);
    }

    // Check if inventory is full
    public boolean isFull() {
        return occupiedSlots >= capacity;
    }

    // Check if inventory has space for new item
    public boolean canAddItem(String itemId, int quantity) {
        boolean isNewItem = !items.containsKey(itemId);
        int requiredSlots = isNewItem ? 1 : 0;
        return occupiedSlots + requiredSlots <= capacity;
    }

    // Transfer items between inventories (e.g., to refrigerator)
    public boolean transferTo(Inventory target, String itemId, int quantity) {
        if (!hasItem(itemId, quantity) || !target.canAddItem(itemId, quantity)) {
            return false;
        }

        if (removeItem(itemId, quantity)) {
            return target.addItem(itemId, quantity);
        }
        return false;
    }

    // Get all items as a read-only map
    public Map<String, Integer> getAllItems() {
        return new HashMap<>(items);
    }

    // Get items filtered by type
    public Map<String, Integer> getItemsByType(Class<?> type) {
        // This assumes items are properly typed in your system
        return items.entrySet().stream()
            .filter(entry -> {
                // You would need to implement item type checking logic
                // For example, check against a registry of item types
                return true; // Simplified for example
            })
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    // Getters
    public int getCapacity() {
        return capacity;
    }

    public int getOccupiedSlots() {
        return occupiedSlots;
    }

    public int getAvailableSlots() {
        return capacity - occupiedSlots;
    }

    @Override
    public String toString() {
        return String.format("Inventory [%d/%d]: %s",
            occupiedSlots, capacity, items.toString());
    }
}
