package io.github.some_example_name.Model;

import java.util.ArrayList;
import java.util.Map;

public class App {
    ArrayList<NPC> AllNPC = new ArrayList<>();
    User CurrentUser;
    ArrayList<Building> AllBuildings = new ArrayList<>();
    Map CurrentMap;

}
