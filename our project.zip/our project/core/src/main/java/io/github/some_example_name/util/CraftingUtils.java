package io.github.some_example_name.util;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.SkillType;

import javax.swing.text.Position;

public class CraftingUtils {
    public static boolean canLearnRecipe(Recipe recipe, Player player) {
        if (recipe.isLearned()) {
            return false;
        }

        // Check skill requirements based on recipe type
        SkillType requiredSkill = getRequiredSkillForRecipe(recipe);
        if (requiredSkill != null) {
            return player.getSkills().getLevel(requiredSkill) >= recipe.getRequiredSkillLevel();
        }
        return true; // Recipes with no skill requirements
    }

    public static boolean isValidPlacementPosition(Position position) {
        // Integration with WorldMap system
        return WorldMap.isPositionValid(position) &&
            WorldMap.isPositionEmpty(position);
    }

    public static Item createItemFromRecipe(Recipe recipe) {
        return new Item(recipe.getId(), recipe.getName(), recipe.getResultType());
    }

    private static SkillType getRequiredSkillForRecipe(Recipe recipe) {
        return switch (recipe.getResultType()) {
            case FURNITURE -> SkillType.CARPENTRY;
            case DECORATION -> SkillType.DESIGN;
            case TOOL -> SkillType.CRAFTING;
            default -> null;
        };
    }
}
