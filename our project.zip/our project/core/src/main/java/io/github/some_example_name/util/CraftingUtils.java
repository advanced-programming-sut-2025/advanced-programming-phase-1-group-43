package io.github.some_example_name.util;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.SkillType;
import io.github.some_example_name.Model.Skill;
import javax.swing.text.Position;


import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.SkillType;

import javax.swing.text.Position;


public class CraftingUtils {
    // ✅ [5 - یادگیری دستور العمل] - بررسی شرایط یادگیری

    public static boolean canLearnRecipe(Recipe recipe, Player player) {
        if (recipe.isLearned()) {
            return false;
        }

        // Check skill requirements based on recipe type
        SkillType requiredSkill = getRequiredSkillForRecipe(recipe);
        if (requiredSkill != null) {
            return player.getSkills().getLevel(requiredSkill) >= recipe.getRequiredSkillLevel();
        }
        return true; // Recipes with no skill requirements
    }
// ✅ [7 - قرار دادن آیتم ها]

    public static boolean isValidPlacementPosition(Position position) {
        // Integration with WorldMap system
        // Map details required
        return WorldMap.isPositionValid(position) &&
            WorldMap.isPositionEmpty(position);
    }
// ✅ [3 - استفاده از دستورالعمل]

    public static Item createItemFromRecipe(Recipe recipe) {
        return new Item(recipe.getId(), recipe.getName(), recipe.getResultType());
    }

    private static SkillType getRequiredSkillForRecipe(Recipe recipe) {
        switch (recipe.getResultType()) {
            case FURNITURE:
                return SkillType.CARPENTRY;
            case DECORATION:
                return SkillType.DESIGN;
            case TOOL:
                return SkillType.CRAFTING;
            default:
                return null;
        }
    }
}
