package io.github.some_example_name.Controller;

public class MapController {
}
