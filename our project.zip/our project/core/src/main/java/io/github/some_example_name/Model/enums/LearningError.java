package io.github.some_example_name.Model.enums;


public enum LearningError {
    RECIPE_NOT_FOUND("Recipe not found"),
    ALREADY_LEARNED("Recipe already learned"),
    INSUFFICIENT_SKILL("Skill level too low"),
    INSUFFICIENT_MATERIALS("Missing required materials");

    private final String message;

    LearningError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
