package io.github.some_example_name.Controller.MenuControllers;
import io.github.some_example_name.Model.enums.ToolMaterial;
import io.github.some_example_name.service.ToolService;

import java.util.Arrays;

public class ToolController {
    private static final String TOOLS_PREFIX = "tools ";
    private static final String EQUIP_CMD = "equip ";
    private static final String USE_CMD = "use -d ";

    private final ToolService toolService;

    public ToolController(ToolService toolService) {
        this.toolService = toolService;
    }

    public String handleCommand(String input) {
        if (!input.startsWith(TOOLS_PREFIX)) {
            return "Invalid tool command";
        }

        String command = input.substring(TOOLS_PREFIX.length());

        if (command.startsWith(EQUIP_CMD)) {
            String toolName = command.substring(EQUIP_CMD.length()).trim();
            return handleEquipCommand(toolName);
        }
        else if (command.startsWith(USE_CMD)) {
            String directionStr = command.substring(USE_CMD.length()).trim();
            return handleUseCommand(directionStr);
        }

        return "Unknown tool command";
    }

    private String handleEquipCommand(String toolName) {
        boolean success = toolService.equipTool(toolName);
        return success ? "Equipped " + toolName : "Failed to equip tool";
    }

    private String handleUseCommand(String directionStr) {
        try {
            int direction = Integer.parseInt(directionStr);
            if (direction < 1 || direction > 8) {
                return "Direction must be between 1-8";
            }

            boolean success = toolService.useTool(direction);
            return success ? "Tool used successfully" : "Tool use failed";
        } catch (NumberFormatException e) {
            return "Invalid direction format";
        }
    }
}
