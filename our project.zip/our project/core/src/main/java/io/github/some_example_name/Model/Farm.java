package io.github.some_example_name.Model;

import io.github.some_example_name.Model.enums.ItemType;
import io.github.some_example_name.Model.enums.SkillType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Farm {
    private final List<Tile> cropTiles = new ArrayList<>();
    private Map<SkillType, List<Recipe>> skillRecipes;
    private List<Recipe> unlockedRecipes;
    /**
     * Automatically water every crop tile on the farm.
     */
    public void autoIrrigate() {
        System.out.println("Auto-irrigating all crops...");
        for (Tile t : cropTiles) {
            t.water();
        }
        this.skillRecipes = new HashMap<>();
        this.unlockedRecipes = new ArrayList<>();
        initializeRecipes();
    }
    private void initializeRecipes() {
        // Initialize recipes for each skill type
        for (SkillType type : SkillType.values()) {
            skillRecipes.put(type, new ArrayList<>());
        }

        // Farming recipes
        addSkillRecipe(SkillType.FARMING, 1,
            new Recipe("basic_crop", "Basic Crop", ItemType.CROP,
                Map.of("seed", 1), 1));

        // Mining recipes
        addSkillRecipe(SkillType.MINING, 2,
            new Recipe("stone_path", "Stone Path", ItemType.DECORATION,
                Map.of("stone", 2), 2));

        // Add more recipes for other skills...
    }
    private void addSkillRecipe(SkillType skillType, int requiredLevel, Recipe recipe) {
        recipe.setRequiredSkillLevel(requiredLevel);
        skillRecipes.get(skillType).add(recipe);
    }
    /**
     * Unlocks recipes based on skill level
     * @param skillType Type of skill that leveled up
     * @param newLevel New skill level
     */
    public void unlockRecipesForSkill(SkillType skillType, int newLevel) {
        skillRecipes.getOrDefault(skillType, new ArrayList<>()).stream()
            .filter(recipe -> recipe.getRequiredSkillLevel() == newLevel)
            .forEach(recipe -> {
                if (!unlockedRecipes.contains(recipe)) {
                    unlockedRecipes.add(recipe);
                    // You can add notification logic here
                }
            });
    }

    // Getters
    public List<Recipe> getUnlockedRecipes() {
        return unlockedRecipes;
    }

    public List<Recipe> getRecipesForSkill(SkillType skillType) {
        return skillRecipes.getOrDefault(skillType, new ArrayList<>());
    }
    public void advanceToNextDay() {
        // Implementation depends on your game logic
        // Typically would call TimeService.advanceDays(1)
    }
    public void savePlayerPosition() {
        // Save the current position to restore after faint
        // Implementation depends on your position system
    }
    /**
     * Randomly strike three tiles with lightning, destroying their crops.
     */
    public void strikeLightning() {
        System.out.println("Lightning storm! Striking random tiles...");
        if (cropTiles.isEmpty()) return;
        for (int i = 0; i < 3; i++) {
            int idx = (int)(Math.random() * cropTiles.size());
            Tile t = cropTiles.get(idx);
            t.destroyCrop();
        }
    }

    /**
     * Add a tile to be managed as a crop tile.
     */
    public void addCropTile(Tile tile) {
        cropTiles.add(tile);
    }

    /**
     * @return an unmodifiable view of crop tiles
     */
    public List<Tile> getCropTiles() {
        return Collections.unmodifiableList(new ArrayList<>(cropTiles));
    }

}
