package io.github.some_example_name.Model;

public class Tree extends Model.Plant {
    private boolean isChoppable;
}
