package io.github.some_example_name.Model.Crops.FoaringTrees;

public class All {
    public static class Acorns {
        public static final String NAME = "Acorns";
        public static final String SEASON = "Special";
    }

    public static class MapleSeeds {
        public static final String NAME = "Maple Seeds";
        public static final String SEASON = "Special";
    }

    public static class PineCones {
        public static final String NAME = "Pine Cones";
        public static final String SEASON = "Special";
    }

    public static class MahoganySeeds {
        public static final String NAME = "Mahogany Seeds";
        public static final String SEASON = "Special";
    }

    public static class MushroomTreeSeeds {
        public static final String NAME = "Mushroom Tree Seeds";
        public static final String SEASON = "Special";
    }
}
