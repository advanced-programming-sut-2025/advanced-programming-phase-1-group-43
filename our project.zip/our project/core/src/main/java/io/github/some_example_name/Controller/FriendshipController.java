package io.github.some_example_name.Controller;


import io.github.some_example_name.Exception.GameException;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.service.FriendshipService;

import java.util.Arrays;
import java.util.List;
import io.github.some_example_name.repository.GameRepository;
import io.github.some_example_name.util.SessionManager;
public class FriendshipController {
    // ✅ [1 - قابلیت صحبت کردن با بازیکنان]

    private final FriendshipService friendshipService;

    public FriendshipController(FriendshipService friendshipService) {
        this.friendshipService = friendshipService;

    }

// ✅ فرمان گل دادن

    public void handleGiveFlower(String targetUsername) {
        Player currentPlayer = SessionManager.getCurrentPlayer();
        Player target = GameRepository.getPlayerByUsername(targetUsername);

        if (target == null) {
            System.out.println("بازیکن مورد نظر پیدا نشد.");
            return;
        }

        try {
            friendshipService.giveFlower(currentPlayer, target);
            System.out.println("گل با موفقیت داده شد.");
        } catch (GameException e) {
            System.out.println("خطا: " + e.getMessage());
        }
    }
    public String handleCommand(String player, String command) {
        String[] parts = command.split(" ");
        String action = parts[0];

        try {
            switch (action) {
                case "talk":
                    return handleTalkCommand(player, parts);
                case "gift":
                    return handleGiftCommand(player, parts);
                case "hug":
                    return handleHugCommand(player, parts);
                case "history":
                    return handleHistoryCommand(player, parts);
                case "rate":
                    return handleRateCommand(player, parts);
                default:
                    return "Unknown friendship command";
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
// ✅ [1 - قابلیت صحبت کردن با بازیکنان]

    private String handleTalkCommand(String player, String[] parts) {
        if (parts.length < 5 || !parts[1].equals("-u") || !parts[3].equals("-m")) {
            return "Usage: talk -u <username> -m <message>";
        }
        String receiver = parts[2];
        String message = String.join(" ", Arrays.copyOfRange(parts, 4, parts.length));

        friendshipService.addChatMessage(player, receiver, message);
        return "Message sent successfully";
    }

    private String handleGiftCommand(String player, String[] parts) {
        if (parts.length < 7 || !parts[1].equals("-u") || !parts[3].equals("-i") || !parts[5].equals("-a")) {
            return "Usage: gift -u <username> -i <item> -a <amount>";
        }
        String receiver = parts[2];
        String item = parts[4];
        int amount = Integer.parseInt(parts[6]);

        Gift gift = friendshipService.sendGift(player, receiver, item, amount);
        return String.format("Gift of %d x %s sent to %s", amount, item, receiver);
    }
// ✅ [1 - قابلیت بغل کردن بازیکنان]

    private String handleHugCommand(String player, String[] parts) {
        if (parts.length < 3 || !parts[1].equals("-u")) {
            return "Usage: hug -u <username>";
        }
        String hugged = parts[2];

        friendshipService.hug(player, hugged);
        return String.format("You hugged %s!", hugged);
    }
// ✅ [4 - نمایش تاریخچه صحبت با هر بازیکن]

    private String handleHistoryCommand(String player, String[] parts) {
        if (parts.length < 3 || !parts[1].equals("-u")) {
            return "Usage: history -u <username>";
        }
        String otherPlayer = parts[2];

        List<ChatMessage> chatHistory = friendshipService.getChatHistory(player, otherPlayer);
        StringBuilder sb = new StringBuilder("Chat history:\n");
        chatHistory.forEach(msg ->
            sb.append(String.format("[%s] %s: %s\n",
                msg.getTimestamp(), msg.getSender(), msg.getMessage()))
        );

        return sb.toString();
    }

    private String handleRateCommand(String player, String[] parts) {
        if (parts.length < 5 || !parts[1].equals("-i") || !parts[3].equals("-r")) {
            return "Usage: rate -i <gift-number> -r <rating>";
        }
        int giftIndex = Integer.parseInt(parts[2]) - 1;
        int rating = Integer.parseInt(parts[4]);

        friendshipService.rateGift(player, giftIndex, rating);
        return "Gift rated successfully";
    }
}
