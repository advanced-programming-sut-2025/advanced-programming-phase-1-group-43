package io.github.some_example_name.Model.enums;


public enum EatingError {
    FOOD_NOT_FOUND("Food not found in inventory"),
    INVALID_FOOD_TYPE("Item is not edible"),
    ALREADY_FULL("Cannot eat - energy already full");

    private final String message;

    EatingError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
