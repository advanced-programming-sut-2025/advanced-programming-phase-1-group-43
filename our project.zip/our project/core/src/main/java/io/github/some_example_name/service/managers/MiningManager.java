package io.github.some_example_name.service.managers;


import io.github.some_example_name.Model.Position;

public class MiningManager {
    public boolean breakRock(Position position, int direction) {
        // پیاده‌سازی منطق شکستن سنگ
        return true;
    }
}
