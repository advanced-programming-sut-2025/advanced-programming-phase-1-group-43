package io.github.some_example_name.service;

import io.github.some_example_name.Exception.GameException;
import io.github.some_example_name.Model.*;
import io.github.some_example_name.Model.enums.FriendshipLevel;
//import javax.swing.text.Position;
import java.util.*;
import java.util.Map;
import io.github.some_example_name.Model.Position;

public class FriendshipService {
    private final Map<String, List<Friendship>> friendships;
    private final PlayerService playerService;
    private final InventoryService inventoryService;

    public FriendshipService(PlayerService playerService, InventoryService inventoryService) {
        this.friendships = new HashMap<>();
        this.playerService = playerService;
        this.inventoryService = inventoryService;
    }

    public Friendship getFriendship(String player1, String player2) {
        String key1 = player1.compareTo(player2) < 0 ? player1 : player2;
        String key2 = player1.compareTo(player2) < 0 ? player2 : player1;

        return friendships.getOrDefault(key1, new ArrayList<>()).stream()
            .filter(f -> f.getPlayer2().equals(key2))
            .findFirst()
            .orElseGet(() -> {
                Friendship newFriendship = new Friendship(key1, key2);
                friendships.computeIfAbsent(key1, k -> new ArrayList<>()).add(newFriendship);
                return newFriendship;
            });
    }
    // ✅ [1 - قابلیت صحبت کردن با بازیکنان]
// ✅ [2 - بالا رفتن xp دوستی با صحبت کردن]
// ✅ [3 - دریافت شدن اعلان توسط بازیکنی که با او صحبت شده]
    public void addChatMessage(String sender, String receiver, String message) {
        if (!arePlayersNearby(sender, receiver)) {
            throw new IllegalStateException("Players must be nearby to chat");
        }

        Friendship friendship = getFriendship(sender, receiver);
        friendship.getChatHistory().add(new ChatMessage(sender, receiver, message));
        friendship.addXp(20); // XP for chatting

        // Notify receiver
        playerService.notifyPlayer(receiver,
            String.format("New message from %s: %s", sender, message));
    }
    // ✅ [2-باز شدن قابلیت هدیه دادن پس از رسیدن به سطح 1دوستی]
// ✅ [3-خارج شدن آیتم از inventory بازیکن هدیه دهنده و دریافت آن توسط گیرنده]
// ✅ [4-اعلان دریافت هدیه برای گیرنده]
// ✅ [5-مشاهده لیست هدیه‌های دریافت شده]
// ✅ [7-اضافه یا کاهش سطح دوستی براساس امتیاز هدیه]
// ✅ [9-خطاهای مربوط به امتیاز دادن هدیه]
// ✅ [10-خطاهای مربوط به هدیه دادن]
    public Gift sendGift(String giver, String receiver, String itemId, int amount) {
        if (!canSendGift(giver, receiver)) {
            throw new IllegalStateException("Cannot send gift at current friendship level");
        }

        if (!arePlayersNearby(giver, receiver)) {
            throw new IllegalStateException("Players must be nearby to send gifts");
        }

        if (!inventoryService.hasItem(giver, itemId, amount)) {
            throw new IllegalStateException("Not enough items to gift");
        }

        // Transfer item
        inventoryService.removeItem(giver, itemId, amount);
        inventoryService.addItem(receiver, itemId, amount);

        // Record gift
        Gift gift = new Gift(giver, receiver, itemId, amount);
        Friendship friendship = getFriendship(giver, receiver);
        friendship.getGifts().add(gift);

        // Notify receiver
        playerService.notifyPlayer(receiver,
            String.format("You received %d x %s from %s", amount, itemId, giver));

        return gift;
    }
    public Friendship getFriendshipBetween(Player p1, Player p2) {
        return getFriendship(p1.getUsername(), p2.getUsername());
    }
// ✅ ارتقا سطح دوستی با گل دادن (پاداش XP، بررسی سطح لازم، چک کردن آیتم گل و کنار هم بودن)

    public void giveFlower(Player from, Player to) throws GameException {
        if (!arePlayersNearby(from, to)) {
            throw new GameException("بازیکنان باید کنار هم باشند.");
        }

        Friendship friendship = getFriendshipBetween(from, to);
        FriendshipLevel currentLevel = friendship.getLevel();

        if (currentLevel != FriendshipLevel.FRIEND || !friendship.isLevelFull(FriendshipLevel.FRIEND)) {
            throw new GameException("برای گل دادن، سطح دوستی 'FRIEND' (سطح ۲) باید پر باشد.");
        }

        if (!from.getInventory().hasItem("Flower", 1)) {
            throw new GameException("بازیکن گل در inventory ندارد.");
        }

        from.getInventory().removeItem("Flower", 1);
        to.getInventory().addItem(new Item("Flower"));

        friendship.addXp(1); // کافیست یک XP بدهیم تا از FRIEND به CLOSE_FRIEND برسد
    }
    // ✅ [6 - امکان امتیاز دادن به هدیه دریافت شده]
// ✅ [7 - اضافه یا کاهش سطح دوستی براساس امتیاز هدیه]
// ✅ [9 - خطاهای مربوط به امتیاز دادن هدیه]
    public void rateGift(String player, int giftIndex, int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1-5");
        }

        List<Gift> receivedGifts = getReceivedGifts(player);
        if (giftIndex < 0 || giftIndex >= receivedGifts.size()) {
            throw new IllegalArgumentException("Invalid gift index");
        }

        Gift gift = receivedGifts.get(giftIndex);
        gift.rate(rating);

        // Update friendship XP based on rating
        int xpChange = 15 * rating - 30; // Formula: 15*rating - 30
        Friendship friendship = getFriendship(gift.getGiver(), player);
        friendship.addXp(xpChange);
    }
    // ✅ [1 - قابلیت بغل کردن بازیکنان]
// ✅ [2 - باز شدن قابلیت بغل کردن پس از رسیدن به سطح دوستی 2]
// ✅ [3 - افزایش سطح دوستی با بغل کردن]
// ✅ [4 - حضور بازیکنان کنار هم هنگام بغل کردن]
    public void hug(String hugger, String hugged) {
        FriendshipLevel currentLevel = getFriendshipLevel(hugger, hugged);
        if (currentLevel.getLevel() < 2) {
            throw new IllegalStateException("Friendship level too low for hugging");
        }

        if (!arePlayersNearby(hugger, hugged)) {
            throw new IllegalStateException("Players must be nearby to hug");
        }

        Friendship friendship = getFriendship(hugger, hugged);
        friendship.addXp(60); // XP for hugging
    }

    private boolean canSendGift(String giver, String receiver) {
        return getFriendshipLevel(giver, receiver).getLevel() >= 1;
    }

    private boolean arePlayersNearby(String player1, String player2) {
        Position pos1 = (Position) playerService.getPlayerPosition(player1);
        Position pos2 = (Position) playerService.getPlayerPosition(player2);
        return pos1.distanceTo(pos2) <= 2; // Assuming 2 units is "nearby"
    }

    public FriendshipLevel getFriendshipLevel(String player1, String player2) {
        return getFriendship(player1, player2).getCurrentLevel();
    }

    public List<Gift> getReceivedGifts(String player) {
        List<Gift> gifts = new ArrayList<>();
        friendships.values().forEach(friendList ->
            friendList.stream()
                .filter(f -> f.getPlayer1().equals(player) || f.getPlayer2().equals(player))
                .forEach(f -> f.getGifts().stream()
                    .filter(g -> g.getReceiver().equals(player))
                    .forEach(gifts::add)
                )
        );
        return gifts;
    }

    public List<ChatMessage> getChatHistory(String player1, String player2) {
        return getFriendship(player1, player2).getChatHistory();
    }
}
