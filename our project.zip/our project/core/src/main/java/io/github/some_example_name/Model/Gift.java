package io.github.some_example_name.Model;

public class Gift {
    private Item item;
    private int amount;
}
