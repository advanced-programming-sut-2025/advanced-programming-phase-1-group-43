package io.github.some_example_name.Model;

import java.time.LocalDateTime;

public class Gift {
    private final String giver;
    private final String receiver;
    private final String itemId;
    private final int amount;
    private final LocalDateTime givenAt;
    private Integer rating;

    public Gift(String giver, String receiver, String itemId, int amount) {
        this.giver = giver;
        this.receiver = receiver;
        this.itemId = itemId;
        this.amount = amount;
        this.givenAt = LocalDateTime.now();
    }

    public void rate(int rating) {
        if (rating >= 1 && rating <= 5) {
            this.rating = rating;
        }
    }

    // Getters
    public String getGiver() { return giver; }
    public String getReceiver() { return receiver; }
    public String getItemId() { return itemId; }
    public int getAmount() { return amount; }
    public LocalDateTime getGivenAt() { return givenAt; }
    public Integer getRating() { return rating; }
}
