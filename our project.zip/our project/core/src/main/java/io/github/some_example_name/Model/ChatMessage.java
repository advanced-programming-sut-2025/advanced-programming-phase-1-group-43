package io.github.some_example_name.Model;


import java.time.LocalDateTime;

public class ChatMessage {
    private final String sender;
    private final String receiver;
    private final String message;
    private final LocalDateTime timestamp;

    public ChatMessage(String sender, String receiver, String message) {
        this.sender = sender;
        this.receiver = receiver;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    // Getters
    public String getSender() { return sender; }
    public String getReceiver() { return receiver; }
    public String getMessage() { return message; }
    public LocalDateTime getTimestamp() { return timestamp; }
}
